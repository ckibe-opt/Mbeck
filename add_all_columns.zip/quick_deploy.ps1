# Quick deployment using curl
$projectId = "mmnnrydehabyokygyxpo"
$serviceRoleKey = "sb_secret_-otP96CroIuua8ITuLTmWA_VnOk2TyH"
$functionCode = Get-Content -Path "IMMEDIATE_FIX.ts" -Raw

# Simple deployment payload
$simplePayload = @{
    "slug" = "sync-events"
    "name" = "sync-events"
    "verify_jwt" = $false
    "files" = @{
        "index.ts" = @{
            "content" = $functionCode
        }
    }
} | ConvertTo-Json -CompressDepth

Write-Host "Deploying via curl..."

# Use curl for deployment
curl.exe -X POST `
    "https://api.supabase.com/v1/projects/$projectId/functions" `
    -H "Authorization: Bearer $serviceRoleKey" `
    -H "Content-Type: application/json" `
    -d $simplePayload

Write-Host "Deployment sent. Testing in 5 seconds..."
Start-Sleep -Seconds 5

# Test deployment
& .\detailed_test.ps1

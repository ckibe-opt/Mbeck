import requests
import json

# Test if the Edge Function is deployed and accessible
def test_edge_function():
    url = "https://mmnnrydehabyokygyxpo.supabase.co/functions/v1/sync-events"
    headers = {
        "Authorization": "Bearer sb_secret_-otP96CroIuua8ITuLTmWA_VnOk2TyH",
        "Content-Type": "application/json"
    }
    
    # Test event payload
    test_event = {
        "id": "test-event-123",
        "event_type": "TEST_EVENT",
        "payload": {"test": True},
        "payload_raw": '{"test": true}',
        "hash": "test-hash",
        "shop_id": "shop_1770821513844_8578",
        "device_id": "device_1770821513622_2893",
        "timestamp": 1234567890000
    }
    
    try:
        response = requests.post(url, headers=headers, json=[test_event])
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.text}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Function is working!")
            print(f"Inserted: {result.get('inserted_count', 0)}")
            print(f"Errors: {result.get('errors', [])}")
        else:
            print(f"❌ Function error: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Connection error: {e}")

if __name__ == "__main__":
    test_edge_function()

# Debug test to see what's actually happening
$headers = @{
    "Authorization" = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1tbm5yeWRlaGFieW9reWd5eHBvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk1OTM5NTEsImV4cCI6MjA4NTE2OTk1MX0.vSwuvySp8wlSXOXPskGmCMyT6BMZ1WMmsRZwX-Mo3Qo"
    "Content-Type" = "application/json"
}

# Test with service role key to bypass any RLS
$serviceHeaders = @{
    "Authorization" = "Bearer sb_secret_-otP96CroIuua8ITuLTmWA_VnOk2TyH"
    "Content-Type" = "application/json"
}

$body = @"
[{
    "id": "debug-test-$(Get-Random)",
    "event_type": "DEBUG_TEST",
    "payload": {"test": "debug"},
    "payload_raw": "{\"test\": \"debug\"}",
    "hash": "debug-hash",
    "shop_id": "shop_1770821513844_8578",
    "device_id": "device_1770821513622_2893",
    "timestamp": 1234567890000
}]
"@

Write-Host "Testing with ANON key:"
try {
    $response = Invoke-RestMethod -Uri "https://mmnnrydehabyokygyxpo.supabase.co/functions/v1/sync-events" -Method POST -Headers $headers -Body $body
    Write-Host "ANON Response: Inserted=$($response.inserted_count), Errors=$($response.errors.Count)"
} catch {
    Write-Host "ANON Error: $($_.Exception.Message)"
}

Write-Host "`nTesting with SERVICE ROLE key:"
try {
    $response = Invoke-RestMethod -Uri "https://mmnnrydehabyokygyxpo.supabase.co/functions/v1/sync-events" -Method POST -Headers $serviceHeaders -Body $body
    Write-Host "SERVICE Response: Inserted=$($response.inserted_count), Errors=$($response.errors.Count)"
} catch {
    Write-Host "SERVICE Error: $($_.Exception.Message)"
}

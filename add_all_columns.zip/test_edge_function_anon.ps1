# Test Edge Function with anon key (like the Flutter app does)
$headers = @{
    "Authorization" = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1tbm5yeWRlaGFieW9reWd5eHBvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk1OTM5NTEsImV4cCI6MjA4NTE2OTk1MX0.vSwuvySp8wlSXOXPskGmCMyT6BMZ1WMmsRZwX-Mo3Qo"
    "Content-Type" = "application/json"
}

$body = @"
[{
    "id": "test-event-123",
    "event_type": "TEST_EVENT", 
    "payload": {"test": true},
    "payload_raw": "{\"test\": true}",
    "hash": "test-hash",
    "shop_id": "shop_1770821513844_8578",
    "device_id": "device_1770821513622_2893", 
    "timestamp": 1234567890000
}]
"@

try {
    $response = Invoke-RestMethod -Uri "https://mmnnrydehabyokygyxpo.supabase.co/functions/v1/sync-events" -Method POST -Headers $headers -Body $body
    Write-Host "✅ Function is working!"
    Write-Host "Response: $response"
} catch {
    Write-Host "❌ Function error: $($_.Exception.Message)"
    Write-Host "Status: $($_.Exception.Response.StatusCode.value__)"
    $errorResponse = $_.Exception.Response.GetResponseStream()
    $reader = New-Object System.IO.StreamReader($errorResponse)
    $reader.BaseStream.Position = 0
    $errorBody = $reader.ReadToEnd()
    Write-Host "Error Body: $errorBody"
}

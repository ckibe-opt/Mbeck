# Check if events are actually in the database
$anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1tbm5yeWRlaGFieW9reWd5eHBvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk1OTM5NTEsImV4cCI6MjA4NTE2OTk1MX0.vSwuvySp8wlSXOXPskGmCMyT6BMZ1WMmsRZwX-Mo3Qo"

$headers = @{
    "Authorization" = "Bearer $anonKey"
    "Content-Type" = "application/json"
    "apikey" = $anonKey
}

try {
    $response = Invoke-RestMethod -Uri "https://mmnnrydehabyokygyxpo.supabase.co/rest/v1/events?select=id,event_type,shop_id,timestamp,created_at&order=created_at.desc&limit=10" -Method GET -Headers $headers
    Write-Host "📊 Recent Events in Database:"
    if ($response.Count -eq 0) {
        Write-Host "❌ No events found in database!"
    } else {
        Write-Host "✅ Found $($response.Count) events:"
        foreach ($evt in $response) {
            Write-Host "  - $($evt.id) | $($evt.event_type) | Shop: $($evt.shop_id) | $($evt.created_at)"
        }
    }
} catch {
    Write-Host "❌ Error querying database: $($_.Exception.Message)"
}

# Check specific shop events
$shopQuery = "https://mmnnrydehabyokygyxpo.supabase.co/rest/v1/events?shop_id=eq.shop_1770821513844_8578&select=id,event_type,created_at&order=created_at.desc&limit=5"

try {
    $shopEvents = Invoke-RestMethod -Uri $shopQuery -Method GET -Headers $headers
    Write-Host "`n🏪 Events for your shop:"
    if ($shopEvents.Count -eq 0) {
        Write-Host "❌ No events found for your shop!"
    } else {
        Write-Host "✅ Found $($shopEvents.Count) events for your shop:"
        foreach ($evt in $shopEvents) {
            Write-Host "  - $($evt.id) | $($evt.event_type) | $($evt.created_at)"
        }
    }
} catch {
    Write-Host "❌ Error querying shop events: $($_.Exception.Message)"
}

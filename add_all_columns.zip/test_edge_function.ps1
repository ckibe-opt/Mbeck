# Test Edge Function deployment
$headers = @{
    "Authorization" = "Bearer sb_secret_-otP96CroIuua8ITuLTmWA_VnOk2TyH"
    "Content-Type" = "application/json"
}

$body = @"
[{
    "id": "test-event-123",
    "event_type": "TEST_EVENT", 
    "payload": {"test": true},
    "payload_raw": "{\"test\": true}",
    "hash": "test-hash",
    "shop_id": "shop_1770821513844_8578",
    "device_id": "device_1770821513622_2893", 
    "timestamp": 1234567890000
}]
"@

try {
    $response = Invoke-RestMethod -Uri "https://mmnnrydehabyokygyxpo.supabase.co/functions/v1/sync-events" -Method POST -Headers $headers -Body $body
    Write-Host "✅ Function is working!"
    Write-Host "Response: $response"
} catch {
    Write-Host "❌ Function error: $($_.Exception.Message)"
    Write-Host "Status: $($_.Exception.Response.StatusCode.value__)"
}

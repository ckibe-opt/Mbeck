# Manual Edge Function Deployment using Supabase Management API
# This bypasses Docker and CLI requirements

# Configuration
$projectId = "mmnnrydehabyokygyxpo"
$functionName = "sync-events"
$serviceRoleKey = "sb_secret_-otP96CroIuua8ITuLTmWA_VnOk2TyH"

# Read the function code
$functionCode = Get-Content -Path "IMMEDIATE_FIX.ts" -Raw

# Create the deployment payload
$payload = @{
    "slug" = $functionName
    "name" = $functionName
    "verify_jwt" = $false
    "import_map" = $null
    "entrypoint_path" = "index.ts"
    "files" = @{
        "index.ts" = @{
            "content" = $functionCode
        }
    }
} | ConvertTo-Json -Depth 10

Write-Host "Deploying function $functionName to project $projectId..."

try {
    # Deploy the function
    $response = Invoke-RestMethod `
        -Uri "https://api.supabase.com/v1/projects/$projectId/functions" `
        -Method POST `
        -Headers @{
            "Authorization" = "Bearer $serviceRoleKey"
            "Content-Type" = "application/json"
        } `
        -Body $payload

    Write-Host "✅ Function deployed successfully!"
    Write-Host "Response: $response"
    
    # Wait a moment for deployment to complete
    Start-Sleep -Seconds 5
    
    # Test the deployment
    Write-Host "Testing deployment..."
    & .\detailed_test.ps1
    
} catch {
    Write-Host "❌ Deployment failed: $($_.Exception.Message)"
    Write-Host "Status: $($_.Exception.Response.StatusCode.value__)"
    
    # Try to get error details
    if ($_.Exception.Response) {
        $errorResponse = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($errorResponse)
        $reader.BaseStream.Position = 0
        $errorBody = $reader.ReadToEnd()
        Write-Host "Error Details: $errorBody"
    }
}

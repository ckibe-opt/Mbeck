# Test the new v2 function
$headers = @{
    "Authorization" = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1tbm5yeWRlaGFieW9reWd5eHBvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk1OTM5NTEsImV4cCI6MjA4NTE2OTk1MX0.vSwuvySp8wlSXOXPskGmCMyT6BMZ1WMmsRZwX-Mo3Qo"
    "Content-Type" = "application/json"
}

$body = @"
[{
    "id": "v2-test-$(Get-Random)",
    "event_type": "V2_TEST",
    "payload": {"test": "v2"},
    "payload_raw": "{\"test\": \"v2\"}",
    "hash": "v2-hash",
    "shop_id": "shop_1770821513844_8578",
    "device_id": "device_1770821513622_2893",
    "timestamp": 1234567890000
}]
"@

try {
    $response = Invoke-RestMethod -Uri "https://mmnnrydehabyokygyxpo.supabase.co/functions/v1/sync-events-v2" -Method POST -Headers $headers -Body $body
    Write-Host "✅ V2 Function Response:"
    Write-Host "Inserted: $($response.inserted_count)"
    Write-Host "Skipped: $($response.skipped_count)"
    Write-Host "Errors: $($response.errors.Count)"
    
    if ($response.errors.Count -gt 0) {
        Write-Host "Error Details:"
        foreach ($errorItem in $response.errors) {
            Write-Host "  - ID: $($errorItem.id), Error: $($errorItem.error)"
        }
    } else {
        Write-Host "🎉 SUCCESS! V2 function works without hash validation!"
    }
} catch {
    Write-Host "❌ V2 Test error: $($_.Exception.Message)"
    Write-Host "Status: $($_.Exception.Response.StatusCode.value__)"
}

# Test with real hash calculation
$headers = @{
    "Authorization" = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1tbm5yeWRlaGFieW9reWd5eHBvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk1OTM5NTEsImV4cCI6MjA4NTE2OTk1MX0.vSwuvySp8wlSXOXPskGmCMyT6BMZ1WMmsRZwX-Mo3Qo"
    "Content-Type" = "application/json"
}

# Create a real event with proper hash calculation
$eventId = "real-test-$(Get-Random)"
$timestamp = [int][double]::Parse((Get-Date -UFormat %s)) * 1000
$payload = '{"test": "real-hash", "timestamp": ' + $timestamp + '}'
$shopId = "shop_1770821513844_8578"
$deviceId = "device_1770821513622_2893"

# Calculate real SHA256 hash (similar to client)
$hashInput = "$eventId|TEST_EVENT|$payload|$timestamp|$shopId|$deviceId"
$bytes = [System.Text.Encoding]::UTF8.GetBytes($hashInput)
$sha256 = [System.Security.Cryptography.SHA256]::Create()
$hashBytes = $sha256.ComputeHash($bytes)
$realHash = ($hashBytes | ForEach-Object { $_.ToString("x2") }) -join ""

Write-Host "🔍 Real Hash Test:"
Write-Host "  Event ID: $eventId"
Write-Host "  Hash Input: $hashInput"
Write-Host "  Calculated Hash: $realHash"

$body = @"
[{
    "id": "$eventId",
    "event_type": "TEST_EVENT",
    "payload": {"test": "real-hash", "timestamp": $timestamp},
    "payload_raw": "$payload",
    "hash": "$realHash",
    "shop_id": "$shopId",
    "device_id": "$deviceId",
    "timestamp": $timestamp
}]
"@

try {
    $response = Invoke-RestMethod -Uri "https://mmnnrydehabyokygyxpo.supabase.co/functions/v1/sync-events" -Method POST -Headers $headers -Body $body
    Write-Host "✅ Real Hash Test Response:"
    Write-Host "Inserted: $($response.inserted_count)"
    Write-Host "Skipped: $($response.skipped_count)"
    Write-Host "Errors: $($response.errors.Count)"
    
    if ($response.errors.Count -gt 0) {
        Write-Host "Error Details:"
        foreach ($errorItem in $response.errors) {
            Write-Host "  - ID: $($errorItem.id), Error: $($errorItem.error)"
        }
    } else {
        Write-Host "🎉 SUCCESS! Real hash worked!"
    }
} catch {
    Write-Host "❌ Real Hash Test error: $($_.Exception.Message)"
    Write-Host "Status: $($_.Exception.Response.StatusCode.value__)"
}

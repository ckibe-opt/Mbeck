import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/shop_session_provider.dart';
import '../../theme/shop_theme_extension.dart';
import '../../utils/num_utils.dart' as nu;
import 'package:mbeck_shared/mbeck_shared.dart';
import 'booking_flow_screen.dart';

/// Service Browse Screen for customers to view available services.
/// 
/// Features:
/// - List services by category
/// - Show duration and pricing
/// - Navigate to booking flow
class ServiceBrowseScreen extends StatefulWidget {
  const ServiceBrowseScreen({super.key});

  @override
  State<ServiceBrowseScreen> createState() => _ServiceBrowseScreenState();
}

class _ServiceBrowseScreenState extends State<ServiceBrowseScreen> {
  List<Map<String, dynamic>> _services = [];
  List<String> _categories = [];
  bool _isLoading = true;
  String? _error;
  String _selectedCategory = 'All';

  @override
  void initState() {
    super.initState();
    _loadServices();
  }

  Future<void> _loadServices() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final session = context.read<ShopSessionProvider>();
      final api = session.api;
      
      if (api == null) {
        throw Exception('Not connected to a shop');
      }

      debugPrint('📋 Fetching services catalog...');
      final items = await api.getServicesCatalog();
      
      // Filter to only active services (handles both int 1 and string "1")
      final activeServices = items.where((s) => nu.toInt(s['active']) == 1).toList();
      
      // Extract unique categories
      final cats = <String>{'All'};
      for (final item in activeServices) {
        final cat = item['category'] as String?;
        if (cat != null && cat.isNotEmpty) {
          cats.add(cat);
        }
      }
      
      if (mounted) {
        setState(() {
          _services = activeServices;
          _categories = cats.toList()..sort();
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint('❌ Error loading services: $e');
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  List<Map<String, dynamic>> get _filteredServices {
    if (_selectedCategory == 'All') return _services;
    return _services.where((s) => s['category'] == _selectedCategory).toList();
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<ShopSessionProvider>();
    
    final ext = Theme.of(context).extension<ShopThemeExtension>() ?? const ShopThemeExtension();
    return Scaffold(
      appBar: AppBar(
        title: Text(session.currentShopName ?? 'Services'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadServices,
          ),
        ],
      ),
      body: Column(
        children: [
          // Category filter
          if (_categories.length > 1)
            SizedBox(
              height: 50,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.symmetric(horizontal: ext.contentPadding.left, vertical: 8),
                itemCount: _categories.length,
                itemBuilder: (context, index) {
                  final cat = _categories[index];
                  final isSelected = _selectedCategory == cat;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Text(cat),
                      selected: isSelected,
                      onSelected: (_) => setState(() => _selectedCategory = cat),
                      selectedColor: Theme.of(context).primaryColor.withOpacity(0.15),
                      checkmarkColor: Theme.of(context).primaryColor,
                      labelStyle: TextStyle(
                        color: isSelected ? Theme.of(context).primaryColor : Colors.black87,
                        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                      ),
                      shape: ext.buildChipShape(borderColor: isSelected ? Theme.of(context).primaryColor : Colors.grey.shade300),
                    ),
                  );
                },
              ),
            ),
          
          // Services list
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Loading services...'),
          ],
        ),
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.wifi_off_rounded, size: 48, color: Colors.red.shade400),
              ),
              const SizedBox(height: 24),
              Text(
                'Couldn\'t load services',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'The shop might be temporarily unavailable.\nCheck your connection and try again.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[600], height: 1.5),
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: _loadServices,
                icon: const Icon(Icons.refresh),
                label: const Text('Try Again'),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_filteredServices.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.purple.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.spa, size: 48, color: Colors.purple.shade400),
            ),
            const SizedBox(height: 24),
            Text(
              'No services available',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _selectedCategory != 'All' 
                  ? 'Try a different category'
                  : 'Check back soon for new offerings!',
              style: TextStyle(color: Colors.grey[600]),
            ),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              onPressed: _loadServices,
              icon: const Icon(Icons.refresh),
              label: const Text('Refresh'),
            ),
          ],
        ),
      );
    }

    final ext = Theme.of(context).extension<ShopThemeExtension>() ?? const ShopThemeExtension();
    return RefreshIndicator(
      onRefresh: _loadServices,
      child: ListView(
        padding: ext.contentPadding,
        children: [
          if (ext.showHero) _buildHeroCard(),
          if (ext.showHero) SizedBox(height: ext.itemSpacing),
          ..._filteredServices.map((s) => _buildServiceCard(s)),
        ],
      ),
    );
  }

  Widget _buildHeroCard() {
    final theme = Theme.of(context);
    final ext = theme.extension<ShopThemeExtension>() ?? const ShopThemeExtension();
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: ext.buildHeroDecoration(primary: theme.primaryColor, secondary: theme.colorScheme.secondary),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: ext.heroDarkText ? theme.primaryColor.withOpacity(0.1) : Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(ext.cardBorderRadius),
            ),
            child: Icon(Icons.spa,
              color: ext.heroDarkText ? theme.primaryColor : Colors.white, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Our Services', style: TextStyle(
                  color: ext.heroDarkText ? theme.textTheme.bodyLarge?.color : Colors.white,
                  fontWeight: FontWeight.bold, fontSize: 18)),
                const SizedBox(height: 4),
                Text(
                  '${_services.length} services  •  ${_categories.length - 1} categories',
                  style: TextStyle(
                    color: ext.heroDarkText ? Colors.grey.shade600 : Colors.white.withOpacity(0.85),
                    fontSize: 13),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildServiceCard(Map<String, dynamic> service) {
    final name = service['name'] as String? ?? 'Unknown';
    final description = service['description'] as String? ?? '';
    final price = nu.toDouble(service['price']);
    final duration = nu.toInt(service['duration_minutes'], 30);

    final theme = Theme.of(context);
    final ext = theme.extension<ShopThemeExtension>() ?? const ShopThemeExtension();

    // Spa-inspired color palette
    final serviceColors = [
      [const Color(0xFF667EEA), const Color(0xFF764BA2)],
      [const Color(0xFF11998E), const Color(0xFF38EF7D)],
      [const Color(0xFFF5576C), const Color(0xFFF093FB)],
      [const Color(0xFF4ECDC4), const Color(0xFF44A08D)],
      [const Color(0xFFFF6B6B), const Color(0xFFFF8E53)],
    ];
    final colorPair = serviceColors[name.hashCode % serviceColors.length];

    return Container(
      margin: EdgeInsets.only(bottom: ext.itemSpacing),
      decoration: ext.buildCardDecoration(
        surface: theme.cardColor,
        accentColor: colorPair[0],
      ),
      clipBehavior: Clip.antiAlias,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(ext.cardBorderRadius),
          onTap: () => _navigateToBooking(service),
          child: Column(
            children: [
              // Gradient header
              Container(
                height: 80,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: colorPair,
                  ),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(ext.cardBorderRadius)),
                ),
                  child: Stack(
                    children: [
                      // Decorative pattern
                      Positioned(
                        right: -20,
                        top: -20,
                        child: Container(
                          width: 100,
                          height: 100,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withValues(alpha: 0.1),
                          ),
                        ),
                      ),
                      Positioned(
                        left: -30,
                        bottom: -30,
                        child: Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withValues(alpha: 0.1),
                          ),
                        ),
                      ),
                      // Duration badge
                      Positioned(
                        top: 12,
                        right: 12,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.schedule,
                                size: 14,
                                color: Colors.white,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '$duration min',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      // Icon
                      Positioned(
                        left: 20,
                        bottom: 12,
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.1),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Icon(
                            Icons.spa,
                            size: 24,
                            color: colorPair[0],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Details section
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                      if (description.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(
                          description,
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 14,
                            height: 1.4,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          // Price
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 8,
                            ),
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Colors.green[600]!, Colors.green[700]!],
                              ),
                              borderRadius: BorderRadius.circular(ext.buttonBorderRadius),
                            ),
                            child: Text(
                              CurrencyFormatter.formatWithCurrency(price),
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          const Spacer(),
                          // Book button
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: colorPair),
                              borderRadius: BorderRadius.circular(ext.buttonBorderRadius),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  'Book',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(width: 4),
                                Icon(
                                  Icons.arrow_forward,
                                  size: 16,
                                  color: Colors.white,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

  void _navigateToBooking(Map<String, dynamic> service) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BookingFlowScreen(service: service),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
import 'package:intl/intl.dart';
import '../../providers/shop_session_provider.dart';

/// Booking Flow Screen for customers to select date/time and book a service.
/// 
/// Flow:
/// 1. Select date
/// 2. Select available time slot
/// 3. Enter customer details
/// 4. Confirm booking
class BookingFlowScreen extends StatefulWidget {
  final Map<String, dynamic> service;
  
  const BookingFlowScreen({super.key, required this.service});

  @override
  State<BookingFlowScreen> createState() => _BookingFlowScreenState();
}

class _BookingFlowScreenState extends State<BookingFlowScreen> {
  int _currentStep = 0;
  DateTime _selectedDate = DateTime.now();
  String? _selectedSlot;
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _notesController = TextEditingController();
  
  List<String> _availableSlots = [];
  bool _isLoadingSlots = false;
  bool _isSubmitting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadAvailableSlots();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _loadAvailableSlots() async {
    setState(() {
      _isLoadingSlots = true;
      _error = null;
      _selectedSlot = null;
    });

    try {
      final session = context.read<ShopSessionProvider>();
      final api = session.api;
      
      if (api == null) {
        throw Exception('Not connected to a shop');
      }

      final dateStr = DateFormat('yyyy-MM-dd').format(_selectedDate);
      debugPrint('📋 Checking availability for $dateStr...');
      
      final slots = await api.getServiceAvailability(widget.service['id'].toString(), dateStr);
      
      // If no slots from API, generate default slots
      final finalSlots = slots.isEmpty ? _generateDefaultSlots() : slots;
      
      if (mounted) {
        setState(() {
          _availableSlots = finalSlots;
          _isLoadingSlots = false;
        });
      }
    } catch (e) {
      debugPrint('Error loading slots: $e');
      if (mounted) {
        setState(() {
          _availableSlots = _generateDefaultSlots();
          _isLoadingSlots = false;
        });
      }
    }
  }

  List<String> _generateDefaultSlots() {
    final slots = <String>[];
    final duration = widget.service['duration_minutes'] as int? ?? 30;
    
    // Generate slots from 9 AM to 5 PM
    var time = const TimeOfDay(hour: 9, minute: 0);
    final endHour = 17;
    
    while (time.hour < endHour) {
      final formatted = '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
      slots.add(formatted);
      
      // Add duration to get next slot
      final totalMinutes = time.hour * 60 + time.minute + duration;
      time = TimeOfDay(hour: totalMinutes ~/ 60, minute: totalMinutes % 60);
    }
    
    return slots;
  }

  Future<void> _submitBooking() async {
    if (_nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your name')),
      );
      return;
    }
    
    if (_phoneController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your phone number')),
      );
      return;
    }

    setState(() {
      _isSubmitting = true;
      _error = null;
    });

    try {
      final session = context.read<ShopSessionProvider>();
      final api = session.api;
      
      if (api == null) {
        throw Exception('Not connected to a shop');
      }

      // Parse selected time
      final timeParts = _selectedSlot!.split(':');
      final startTime = DateTime(
        _selectedDate.year,
        _selectedDate.month,
        _selectedDate.day,
        int.parse(timeParts[0]),
        int.parse(timeParts[1]),
      );
      
      final duration = widget.service['duration_minutes'] as int? ?? 30;
      final endTime = startTime.add(Duration(minutes: duration));

      final bookingData = {
        'service_id': widget.service['id'],
        'customer_name': _nameController.text.trim(),
        'customer_phone': _phoneController.text.trim(),
        'start_time': startTime.millisecondsSinceEpoch,
        'end_time': endTime.millisecondsSinceEpoch,
        'notes': _notesController.text.trim(),
      };

      debugPrint('📋 Submitting booking...');
      final success = await api.submitBooking(bookingData);

      if (success) {
        if (mounted) {
          _showConfirmation();
        }
      } else {
        throw Exception('Booking failed. Please try again.');
      }
    } catch (e) {
      debugPrint('Error submitting booking: $e');
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isSubmitting = false;
        });
      }
    }
  }

  void _showConfirmation() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        icon: const Icon(Icons.check_circle, color: Colors.green, size: 64),
        title: const Text('Booking Confirmed! 🎉'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${widget.service['name']}'),
            const SizedBox(height: 8),
            Text(
              '${DateFormat('EEEE, MMM d').format(_selectedDate)} at $_selectedSlot',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            const Text('We look forward to seeing you!'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context); // Back to browse
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final serviceName = widget.service['name'] as String? ?? 'Service';
    final price = (widget.service['price'] as num?)?.toDouble() ?? 0.0;
    final duration = widget.service['duration_minutes'] as int? ?? 30;
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Book $serviceName'),
      ),
      body: Stepper(
        currentStep: _currentStep,
        onStepContinue: () {
          if (_currentStep == 0) {
            setState(() => _currentStep = 1);
          } else if (_currentStep == 1) {
            if (_selectedSlot == null) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Please select a time slot')),
              );
              return;
            }
            setState(() => _currentStep = 2);
          } else if (_currentStep == 2) {
            _submitBooking();
          }
        },
        onStepCancel: () {
          if (_currentStep > 0) {
            setState(() => _currentStep--);
          } else {
            Navigator.pop(context);
          }
        },
        controlsBuilder: (context, details) {
          final isLastStep = _currentStep == 2;
          return Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Row(
              children: [
                ElevatedButton(
                  onPressed: _isSubmitting ? null : details.onStepContinue,
                  child: _isSubmitting
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Text(isLastStep ? 'Confirm Booking' : 'Continue'),
                ),
                const SizedBox(width: 12),
                TextButton(
                  onPressed: _isSubmitting ? null : details.onStepCancel,
                  child: Text(_currentStep == 0 ? 'Cancel' : 'Back'),
                ),
              ],
            ),
          );
        },
        steps: [
          // Step 1: Select Date
          Step(
            title: const Text('Select Date'),
            isActive: _currentStep >= 0,
            state: _currentStep > 0 ? StepState.complete : StepState.indexed,
            content: _buildDatePicker(),
          ),
          
          // Step 2: Select Time
          Step(
            title: const Text('Select Time'),
            isActive: _currentStep >= 1,
            state: _currentStep > 1 ? StepState.complete : StepState.indexed,
            content: _buildTimeSlots(),
          ),
          
          // Step 3: Your Details
          Step(
            title: const Text('Your Details'),
            isActive: _currentStep >= 2,
            state: _currentStep > 2 ? StepState.complete : StepState.indexed,
            content: _buildDetailsForm(price, duration),
          ),
        ],
      ),
    );
  }

  Widget _buildDatePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CalendarDatePicker(
          initialDate: _selectedDate,
          firstDate: DateTime.now(),
          lastDate: DateTime.now().add(const Duration(days: 30)),
          onDateChanged: (date) {
            setState(() => _selectedDate = date);
            _loadAvailableSlots();
          },
        ),
      ],
    );
  }

  Widget _buildTimeSlots() {
    if (_isLoadingSlots) {
      return const Padding(
        padding: EdgeInsets.all(20),
        child: Center(child: CircularProgressIndicator()),
      );
    }

    if (_availableSlots.isEmpty) {
      return Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Icon(Icons.event_busy, size: 48, color: Colors.grey[400]),
            const SizedBox(height: 12),
            const Text('No available slots for this date'),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () {
                setState(() => _currentStep = 0);
              },
              child: const Text('Choose another date'),
            ),
          ],
        ),
      );
    }

    // Gradient colors for time slots
    const slotGradient = [Color(0xFF667EEA), Color(0xFF764BA2)];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Available times on ${DateFormat('EEEE, MMM d').format(_selectedDate)}:',
          style: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            childAspectRatio: 2.2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemCount: _availableSlots.length,
          itemBuilder: (context, index) {
            final slot = _availableSlots[index];
            final isSelected = _selectedSlot == slot;
            
            return GestureDetector(
              onTap: () => setState(() => _selectedSlot = slot),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  gradient: isSelected
                      ? const LinearGradient(colors: slotGradient)
                      : null,
                  color: isSelected ? null : Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                  border: isSelected
                      ? null
                      : Border.all(color: Colors.grey[300]!),
                  boxShadow: isSelected
                      ? [
                          BoxShadow(
                            color: slotGradient[0].withValues(alpha: 0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ]
                      : null,
                ),
                child: Center(
                  child: Text(
                    slot,
                    style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[700],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildDetailsForm(double price, int duration) {
    // Service gradient colors
    const serviceGradient = [Color(0xFF667EEA), Color(0xFF764BA2)];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Summary card with gradient
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: serviceGradient,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: serviceGradient[0].withValues(alpha: 0.3),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.spa,
                      color: Colors.white,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      widget.service['name'] ?? 'Service',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.calendar_today, size: 16, color: Colors.white),
                    const SizedBox(width: 8),
                    Text(
                      '${DateFormat('EEEE, MMM d').format(_selectedDate)} at $_selectedSlot',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.schedule, size: 16, color: Colors.white70),
                  const SizedBox(width: 4),
                  Text(
                    '$duration min',
                    style: const TextStyle(color: Colors.white70),
                  ),
                  const SizedBox(width: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      CurrencyFormatter.formatWithCurrency(price),
                      style: TextStyle(
                        color: serviceGradient[0],
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        
        // Form fields with rounded design
        const Text(
          'Contact Information',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 12),
        
        // Name
        TextField(
          controller: _nameController,
          decoration: InputDecoration(
            labelText: 'Your Name',
            hintText: 'Enter your full name',
            prefixIcon: const Icon(Icons.person_outline),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            filled: true,
            fillColor: Colors.grey[50],
          ),
        ),
        const SizedBox(height: 16),
        
        // Phone
        TextField(
          controller: _phoneController,
          keyboardType: TextInputType.phone,
          decoration: InputDecoration(
            labelText: 'Phone Number',
            hintText: '0712 345 678',
            prefixIcon: const Icon(Icons.phone_outlined),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            filled: true,
            fillColor: Colors.grey[50],
          ),
        ),
        const SizedBox(height: 16),
        
        // Notes
        TextField(
          controller: _notesController,
          maxLines: 3,
          decoration: InputDecoration(
            labelText: 'Special Requests',
            hintText: 'Any preferences or allergies we should know about?',
            prefixIcon: const Padding(
              padding: EdgeInsets.only(bottom: 40),
              child: Icon(Icons.notes_outlined),
            ),
            alignLabelWithHint: true,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            filled: true,
            fillColor: Colors.grey[50],
          ),
        ),
        
        if (_error != null)
          Container(
            margin: const EdgeInsets.only(top: 16),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.red[50],
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.red[200]!),
            ),
            child: Row(
              children: [
                const Icon(Icons.error_outline, color: Colors.red),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../providers/shop_session_provider.dart';
import '../services/shop_api_service.dart';

/// Receipts screen — scan QR from seller to fetch receipt, view history.
class ReceiptsScreen extends StatefulWidget {
  const ReceiptsScreen({super.key});

  @override
  State<ReceiptsScreen> createState() => _ReceiptsScreenState();
}

class _ReceiptsScreenState extends State<ReceiptsScreen> {
  List<Map<String, dynamic>> _receipts = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadSavedReceipts();
  }

  Future<void> _loadSavedReceipts() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('buyer_receipts');
    if (raw != null) {
      try {
        final list = List<Map<String, dynamic>>.from(jsonDecode(raw));
        setState(() => _receipts = list);
      } catch (_) {}
    }
  }

  Future<void> _saveReceipts() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('buyer_receipts', jsonEncode(_receipts));
  }

  void _addReceipt(Map<String, dynamic> receipt) {
    // Avoid duplicates
    final txnId = receipt['transactionId']?.toString();
    if (txnId != null && _receipts.any((r) => r['transactionId']?.toString() == txnId)) return;
    setState(() => _receipts.insert(0, receipt));
    _saveReceipts();
  }

  void _openQrScanner() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => FractionallySizedBox(
        heightFactor: 0.75,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.qr_code_scanner),
                  const SizedBox(width: 8),
                  const Text('Scan Receipt QR', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Spacer(),
                  IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
                ],
              ),
            ),
            Expanded(
              child: MobileScanner(
                onDetect: (capture) async {
                  final barcodes = capture.barcodes;
                  if (barcodes.isEmpty) return;
                  final code = barcodes.first.rawValue;
                  if (code == null) return;

                  Navigator.pop(ctx);
                  await _fetchReceiptFromQr(code);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text('Scan the QR code shown on the seller\'s app', style: TextStyle(color: Colors.grey.shade600)),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _fetchReceiptFromQr(String code) async {
    setState(() => _isLoading = true);

    try {
      // QR code could be a transaction ID, signature, or JSON with connection info
      String? txnId;
      String? ip;
      int port = 8080;

      if (code.startsWith('{')) {
        // JSON format: {"txnId": "123", "ip": "192.168.1.5", "port": 8080}
        final json = jsonDecode(code) as Map<String, dynamic>;
        txnId = json['txnId']?.toString() ?? json['signature']?.toString();
        ip = json['ip'] as String?;
        port = (json['port'] as num?)?.toInt() ?? 8080;
      } else {
        // Plain txnId or signature
        txnId = code;
      }

      if (txnId == null || txnId.isEmpty) {
        _showError('Invalid QR code');
        return;
      }

      // Try connected shop first, then provided IP
      final session = context.read<ShopSessionProvider>();
      
      ShopApiService? api;
      
      if (ip != null) {
        // Fallback for scanning a manual QR code when disconnected
        api = LocalShopApiService(ip: ip, port: port);
      } else {
        api = session.api;
      }

      if (api == null) {
        _showError('Not connected to any shop. Connect first or scan a QR with shop info.');
        return;
      }

      final receipt = await api.getReceipt(txnId);

      if (receipt != null) {
        _addReceipt(receipt);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.check_circle, color: Colors.white),
                const SizedBox(width: 8),
                Text('Receipt from ${receipt['shopName'] ?? 'Shop'} saved'),
              ]),
              backgroundColor: Colors.green.shade600,
            ),
          );
        }
      } else {
        _showError('Receipt not found');
      }
    } catch (e) {
      _showError('Failed to fetch receipt: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: Colors.red));
  }

  String _formatTimestamp(dynamic ts) {
    if (ts == null) return '';
    final millis = ts is int ? ts : int.tryParse(ts.toString()) ?? 0;
    if (millis == 0) return '';
    final dt = DateTime.fromMillisecondsSinceEpoch(millis);
    return '${dt.day}/${dt.month}/${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }

  String _moduleLabel(String? module) {
    switch (module) {
      case 'restaurant': return 'Restaurant';
      case 'services': return 'Service';
      case 'entertainment': return 'Entertainment';
      case 'lodging': return 'Lodging';
      case 'retail': return 'Retail';
      default: return 'Sale';
    }
  }

  IconData _moduleIcon(String? module) {
    switch (module) {
      case 'restaurant': return Icons.restaurant;
      case 'services': return Icons.spa;
      case 'entertainment': return Icons.sports_esports;
      case 'lodging': return Icons.hotel;
      case 'retail': return Icons.storefront;
      default: return Icons.receipt;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Receipts'),
        actions: [
          if (_receipts.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined),
              tooltip: 'Clear All',
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Clear All Receipts?'),
                    content: const Text('This cannot be undone.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                      FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Clear')),
                    ],
                  ),
                );
                if (confirm == true) {
                  setState(() => _receipts.clear());
                  _saveReceipts();
                }
              },
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _receipts.isEmpty
              ? _buildEmptyState(theme)
              : _buildReceiptList(theme),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openQrScanner,
        icon: const Icon(Icons.qr_code_scanner),
        label: const Text('Scan Receipt'),
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(color: Colors.grey.shade100, shape: BoxShape.circle),
              child: Icon(Icons.receipt_long_outlined, size: 48, color: Colors.grey.shade400),
            ),
            const SizedBox(height: 24),
            Text('No receipts yet', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(
              'After a purchase, scan the QR code shown on the seller\'s app to save your receipt.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
            ),
            const SizedBox(height: 32),
            OutlinedButton.icon(
              onPressed: _openQrScanner,
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Scan a Receipt'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReceiptList(ThemeData theme) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _receipts.length,
      itemBuilder: (context, index) {
        final r = _receipts[index];
        final module = r['sourceModule'] as String?;
        final amount = (r['amount'] as num?)?.toDouble() ?? 0;
        final shopName = r['shopName'] as String? ?? 'Shop';
        final currency = r['currency'] as String? ?? 'KES';

        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: InkWell(
            onTap: () => _showReceiptDetail(r),
            borderRadius: BorderRadius.circular(12),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                    child: Icon(_moduleIcon(module), color: theme.primaryColor),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(shopName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        const SizedBox(height: 2),
                        Text('${_moduleLabel(module)} · ${_formatTimestamp(r['timestamp'])}',
                          style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                      ],
                    ),
                  ),
                  Text(CurrencyFormatter.formatWithCurrency(amount, currency: currency),
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: theme.primaryColor)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showReceiptDetail(Map<String, dynamic> r) {
    final module = r['sourceModule'] as String?;
    final amount = (r['amount'] as num?)?.toDouble() ?? 0;
    final shopName = r['shopName'] as String? ?? 'Shop';
    final currency = r['currency'] as String? ?? 'KES';
    final txnId = r['transactionId']?.toString() ?? '';
    final signature = r['signature'] as String? ?? '';
    final details = r['details'] as String? ?? '';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 20),
            // Shop name
            Row(
              children: [
                Icon(_moduleIcon(module), size: 28, color: Theme.of(ctx).primaryColor),
                const SizedBox(width: 12),
                Text(shopName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              ],
            ),
            const SizedBox(height: 16),
            // Amount
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(12)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('$currency ${amount.toStringAsFixed(2)}', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.green.shade700)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Details
            _infoRow('Type', _moduleLabel(module)),
            _infoRow('Date', _formatTimestamp(r['timestamp'])),
            _infoRow('Transaction ID', txnId),
            if (details.isNotEmpty) _infoRow('Details', details),
            if (signature.isNotEmpty) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(8)),
                child: Text('Sig: ${signature.length > 20 ? '${signature.substring(0, 20)}...' : signature}',
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade500, fontFamily: 'monospace')),
              ),
            ],
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SizedBox(width: 120, child: Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 13))),
          Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13))),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
import '../../providers/starred_provider.dart';
import '../../providers/shop_session_provider.dart';
import '../../providers/cart_provider.dart';
import '../../renderers/design_registry.dart';
import '../../utils/num_utils.dart' as nu;
import '../cart_screen.dart';
import '../starred_items_screen.dart';

/// Restaurant Menu Screen for buyer.
///
/// Uses ModuleDesign renderers for visual theming.
/// Buyers can star items, view business contact, and add dishes to cart.
class RestaurantMenuScreen extends StatefulWidget {
  const RestaurantMenuScreen({super.key});

  @override
  State<RestaurantMenuScreen> createState() => _RestaurantMenuScreenState();
}

class _RestaurantMenuScreenState extends State<RestaurantMenuScreen> {
  List<Map<String, dynamic>> _menuItems = [];
  List<String> _categories = [];
  String _selectedCategory = 'All';
  String _searchQuery = '';
  bool _isLoading = true;
  String? _error;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadMenu();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadMenu() async {
    setState(() { _isLoading = true; _error = null; });
    try {
      final session = context.read<ShopSessionProvider>();
      final api = session.api;
      if (api == null) throw Exception('Not connected');

      final items = await api.getRestaurantMenu();

      final cats = <String>{'All'};
      for (final item in items) {
        cats.add(item['category'] as String? ?? 'Other');
      }

      if (mounted) {
        setState(() {
          _menuItems = items;
          _categories = cats.toList()..sort();
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  List<Map<String, dynamic>> get _filteredItems {
    var items = _menuItems;
    if (_selectedCategory != 'All') {
      items = items.where((i) => (i['category'] as String? ?? 'Other') == _selectedCategory).toList();
    }
    if (_searchQuery.isNotEmpty) {
      items = items.where((i) {
        final name = (i['name'] as String? ?? '').toLowerCase();
        final desc = (i['description'] as String? ?? '').toLowerCase();
        return name.contains(_searchQuery.toLowerCase()) || desc.contains(_searchQuery.toLowerCase());
      }).toList();
    }
    return items;
  }

  int get _availableCount => _menuItems.where((i) => (i['available'] as int?) == 1).length;

  ModuleDesign _getDesign() {
    final session = context.read<ShopSessionProvider>();
    final themeConfig = session.currentShopTheme;
    final designId = themeConfig?.designForModule('restaurant') ?? 'clean_standard';
    return DesignRegistry.resolve(designId);
  }

  void _handleCall() async {
    final session = context.read<ShopSessionProvider>();
    final phone = session.currentShopTheme?.phoneNumber;
    if (phone != null && phone.isNotEmpty) {
      final uri = Uri.parse('tel:$phone');
      if (await canLaunchUrl(uri)) await launchUrl(uri);
    }
  }

  void _handleDirections() async {
    final session = context.read<ShopSessionProvider>();
    final config = session.currentShopTheme;
    if (config?.latitude != null && config?.longitude != null) {
      final uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=${config!.latitude},${config.longitude}');
      if (await canLaunchUrl(uri)) await launchUrl(uri);
    } else if (config?.locationAddress != null) {
      final uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(config!.locationAddress!)}');
      if (await canLaunchUrl(uri)) await launchUrl(uri);
    }
  }

  /// Adds a menu item to cart. If it has modifier_groups, shows a selection
  /// sheet first so the buyer can customise their order.
  void _addMenuItemToCart(Map<String, dynamic> item) {
    final isAvailable = (item['available'] as int?) != 0;
    if (!isAvailable) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${item['name']} is currently unavailable'),
          backgroundColor: Colors.orange.shade700,
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }

    final modifierGroups = item['modifier_groups'] as List<dynamic>?;

    if (modifierGroups != null && modifierGroups.isNotEmpty) {
      // Show modifier selection sheet before adding to cart
      _showModifierSheet(item, modifierGroups);
    } else {
      _commitMenuItemToCart(item, []);
    }
  }

  /// Show a bottom sheet to collect modifier choices, then add to cart.
  void _showModifierSheet(
    Map<String, dynamic> item,
    List<dynamic> modifierGroups,
  ) {
    final selectedModifiers = <String>[];
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      item['name'] as String? ?? 'Customise',
                      style: Theme.of(ctx).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const Divider(),
              ...modifierGroups.map((group) {
                final groupName = group['name'] as String? ?? 'Options';
                final options = (group['options'] as List<dynamic>? ?? []);
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Text(
                        groupName,
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                      ),
                    ),
                    ...options.map((opt) {
                      final optName = opt['name'] as String? ?? opt.toString();
                      final isSelected = selectedModifiers.contains(optName);
                      return CheckboxListTile(
                        dense: true,
                        value: isSelected,
                        title: Text(optName),
                        onChanged: (_) => setSheetState(() {
                          if (isSelected) {
                            selectedModifiers.remove(optName);
                          } else {
                            selectedModifiers.add(optName);
                          }
                        }),
                        controlAffinity: ListTileControlAffinity.leading,
                        contentPadding: EdgeInsets.zero,
                      );
                    }),
                  ],
                );
              }),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () {
                    Navigator.pop(ctx);
                    _commitMenuItemToCart(item, List<String>.from(selectedModifiers));
                  },
                  icon: const Icon(Icons.add_shopping_cart),
                  label: const Text('Add to Cart', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Commits the menu item (with chosen modifiers) to CartProvider.
  void _commitMenuItemToCart(Map<String, dynamic> item, List<String> modifiers) {
    final cart = context.read<CartProvider>();
    cart.addMenuItem(
      id: item['id']?.toString() ?? '',
      name: item['name'] as String? ?? 'Dish',
      price: nu.toDouble(item['price']),
      imagePath: item['image_path'] as String?,
      modifiers: modifiers.isEmpty ? null : modifiers,
    );
    final name = item['name'] as String? ?? 'Item';
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text('$name added to cart')),
          ],
        ),
        duration: const Duration(seconds: 2),
        action: SnackBarAction(
          label: 'View Cart',
          textColor: Colors.amber,
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CartScreen()),
          ),
        ),
      ),
    );
  }

  void _showItemDetails(Map<String, dynamic> item) {
    final session = context.read<ShopSessionProvider>();
    final starred = context.read<StarredProvider>();
    final shopId = session.currentShopId ?? '';
    final shopName = session.currentShopName ?? 'Restaurant';
    
    final designId = session.currentShopTheme?.designForModule('restaurant') ?? 'clean_standard';
    final design = DesignRegistry.resolve(designId);
    final isAvailable = (item['available'] as int?) != 0;
    final price = nu.toDouble(item['price']);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Stack(
        children: [
          design.buildItemDetailSheet(
            context,
            item: item,
            isStarred: starred.isStarred(item['id']?.toString() ?? '', shopId),
            onStar: () => starred.toggle(
              id: item['id']?.toString() ?? '',
              name: item['name'] ?? 'Unknown',
              module: 'restaurant',
              price: price,
              imagePath: item['image_path'] as String?,
              category: item['category'] as String?,
              description: item['description'] as String?,
              shopId: shopId,
              shopName: shopName,
            ),
            phoneNumber: session.currentShopTheme?.phoneNumber,
            locationAddress: session.currentShopTheme?.locationAddress,
            onCall: _handleCall,
            onDirections: _handleDirections,
          ),
          // ── "Add to Cart" action bar at sheet bottom ──────────
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: FilledButton.icon(
                  onPressed: isAvailable
                      ? () {
                          Navigator.pop(ctx);
                          _addMenuItemToCart(item);
                        }
                      : null,
                  icon: const Icon(Icons.add_shopping_cart),
                  label: Text(
                    isAvailable
                        ? 'Add to Cart  •  ${CurrencyFormatter.formatWithCurrency(price)}'
                        : 'Not Available',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                  style: FilledButton.styleFrom(
                    minimumSize: const Size.fromHeight(52),
                    backgroundColor: isAvailable ? null : Colors.grey.shade400,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    final session = context.watch<ShopSessionProvider>();
    final starred = context.watch<StarredProvider>();
    final design = _getDesign();
    final shopId = session.currentShopId ?? '';
    final shopName = session.currentShopName ?? 'Restaurant';
    final filtered = _filteredItems;

    final immersiveBody = design.buildImmersiveBody(
      context,
      module: 'restaurant',
      shopName: shopName,
      items: _menuItems,
      categories: _categories,
      selectedCategory: _selectedCategory,
      onCategorySelected: (cat) => setState(() => _selectedCategory = cat),
      searchQuery: _searchQuery,
      onSearchChanged: (v) => setState(() => _searchQuery = v),
      isLoading: _isLoading,
      onRefresh: _loadMenu,
      itemRenderer: (item) {
        final itemId = item['id']?.toString() ?? '0';
        return design.buildMenuItemCard(
          context,
          item: item,
          isStarred: starred.isStarred(itemId, shopId),
          onStar: () => starred.toggle(
            id: itemId,
            name: item['name'] ?? 'Unknown',
            module: 'restaurant',
            price: nu.toDouble(item['price']),
            imagePath: item['image_path'] as String?,
            category: item['category'] as String?,
            description: item['description'] as String?,
            shopId: shopId,
            shopName: shopName,
          ),
          onTap: () => _showItemDetails(item),
          index: 0,
        );
      },
    );

    return Scaffold(
      appBar: immersiveBody != null ? null : AppBar(

        title: const Text('Menu'),
        actions: [
          _buildStarBadge(starred, shopId),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _buildErrorState()
              : immersiveBody ?? (_menuItems.isEmpty
                  ? _buildEmptyState()
                  : RefreshIndicator(

                      onRefresh: _loadMenu,
                      child: CustomScrollView(
                        slivers: [
                          // Hero
                          SliverToBoxAdapter(child: Padding(
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                            child: design.buildMenuHero(context,
                              itemCount: _availableCount,
                              categoryCount: _categories.length - 1,
                            ),
                          )),
                          // Search
                          SliverToBoxAdapter(child: design.buildSearchBar(
                            context,
                            controller: _searchController,
                            onChanged: (v) => setState(() => _searchQuery = v),
                            hint: 'Search menu...',
                          )),
                          // Categories
                          if (_categories.length > 2)
                            SliverToBoxAdapter(child: design.buildCategoryNav(
                              context,
                              categories: _categories,
                              selected: _selectedCategory,
                              onSelect: (cat) => setState(() => _selectedCategory = cat),
                            )),
                          // Count
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: Text(
                                '${filtered.length} dish${filtered.length == 1 ? '' : 'es'}',
                                style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.w500, fontSize: 14),
                              ),
                            ),
                          ),
                          // Menu items
                          filtered.isEmpty
                              ? SliverFillRemaining(
                                  hasScrollBody: false,
                                  child: Center(child: Text('No dishes match your search', style: TextStyle(color: Colors.grey.shade500))),
                                )
                              : SliverPadding(
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                  sliver: SliverList(
                                    delegate: SliverChildBuilderDelegate(
                                      (context, i) {
                                        final item = filtered[i];
                                        final itemId = item['id']?.toString() ?? '$i';
                                        return Padding(
                                          padding: const EdgeInsets.only(bottom: 10),
                                          child: design.buildMenuItemCard(
                                            context,
                                            item: item,
                                            isStarred: starred.isStarred(itemId, shopId),
                                            onStar: () => starred.toggle(
                                              id: itemId,
                                              name: item['name'] ?? 'Unknown',
                                              module: 'restaurant',
                                              price: nu.toDouble(item['price']),
                                              imagePath: item['image_path'] as String?,
                                              category: item['category'] as String?,
                                              description: item['description'] as String?,
                                              shopId: shopId,
                                              shopName: shopName,
                                            ),
                                            onTap: () => _showItemDetails(item),
                                            index: i,
                                          ),
                                        );
                                      },
                                      childCount: filtered.length,
                                    ),
                                  ),
                                ),
                          const SliverToBoxAdapter(child: SizedBox(height: 24)),
                        ],
                      ),
                    )),

      bottomNavigationBar: design.buildContactBar(
        context,
        shopName: shopName,
        phoneNumber: session.currentShopTheme?.phoneNumber,
        locationAddress: session.currentShopTheme?.locationAddress,
        onCall: _handleCall,
        onDirections: _handleDirections,
      ),
      floatingActionButton: Consumer<CartProvider>(
        builder: (context, cart, _) {
          if (cart.itemCount == 0) return const SizedBox.shrink();
          return FloatingActionButton.extended(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CartScreen()),
            ),
            icon: const Icon(Icons.shopping_cart),
            label: Text('${cart.itemCount} item${cart.itemCount == 1 ? '' : 's'}  •  ${CurrencyFormatter.formatWithCurrency(cart.grandTotal)}'),
            backgroundColor: Theme.of(context).colorScheme.primary,
            foregroundColor: Colors.white,
          );
        },
      ),
    );
  }

  Widget _buildStarBadge(StarredProvider starred, String shopId) {
    final count = starred.forShop(shopId).where((s) => s.module == 'restaurant').length;
    if (count == 0) return const SizedBox.shrink();
    return Stack(
      children: [
        IconButton(
          icon: const Icon(Icons.star_outlined), 
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const StarredItemsScreen()),
            );
          },
        ),
        Positioned(
          right: 4, top: 4,
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: const BoxDecoration(color: Colors.amber, shape: BoxShape.circle),
            constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
            child: Text('$count', style: const TextStyle(color: Colors.black, fontSize: 10, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          ),
        ),
      ],
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.cloud_off, size: 64, color: Colors.red.shade200),
            const SizedBox(height: 16),
            Text('Could not load menu', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey.shade700)),
            const SizedBox(height: 8),
            Text(_error!, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade500)),
            const SizedBox(height: 24),
            FilledButton.icon(onPressed: _loadMenu, icon: const Icon(Icons.refresh), label: const Text('Retry')),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.restaurant_menu, size: 64, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text('Menu is empty', style: TextStyle(fontSize: 16, color: Colors.grey.shade600)),
          const SizedBox(height: 8),
          Text('This restaurant hasn\'t added menu items yet', style: TextStyle(color: Colors.grey.shade400)),
        ],
      ),
    );
  }
}



import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
import '../../providers/cart_provider.dart';
import '../../providers/shop_session_provider.dart';
import '../../services/order_service.dart';
import '../cart_screen.dart';

/// Restaurant Order Screen for placing orders.
/// 
/// Allows customers to:
/// - Select order type (dine-in, takeaway)
/// - Enter table number for dine-in
/// - Add special instructions/notes
/// - Submit order to restaurant
class RestaurantOrderScreen extends StatefulWidget {
  const RestaurantOrderScreen({super.key});

  @override
  State<RestaurantOrderScreen> createState() => _RestaurantOrderScreenState();
}

class _RestaurantOrderScreenState extends State<RestaurantOrderScreen> {
  final _formKey = GlobalKey<FormState>();
  final _tableController = TextEditingController();
  final _noteController = TextEditingController();
  
  bool _isSubmitting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    // Initialize from cart state
    final cart = context.read<CartProvider>();
    if (cart.tableNumber != null) {
      _tableController.text = cart.tableNumber.toString();
    }
    if (cart.customerNote != null) {
      _noteController.text = cart.customerNote!;
    }
  }

  @override
  void dispose() {
    _tableController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _submitOrder() async {
    if (!_formKey.currentState!.validate()) return;
    
    final cart = context.read<CartProvider>();
    final session = context.read<ShopSessionProvider>();
    
    if (cart.items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your cart is empty')),
      );
      return;
    }
    
    // Validate dine-in table number
    if (cart.orderType == OrderType.dineIn) {
      final tableNum = int.tryParse(_tableController.text);
      if (tableNum == null || tableNum < 1) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please enter a valid table number')),
        );
        return;
      }
      cart.setTableNumber(tableNum);
    }
    
    cart.setCustomerNote(_noteController.text.isEmpty ? null : _noteController.text);
    
    setState(() {
      _isSubmitting = true;
      _error = null;
    });

    try {
      final ip = session.currentIp;
      final port = session.currentPort;
      
      if (ip == null || port == null) {
        throw Exception('Not connected to a shop');
      }

      // Build order payload
      final orderData = {
        'order_type': cart.orderType.name,
        'table_number': cart.tableNumber,
        'customer_note': cart.customerNote,
        'items': cart.items.map((item) => {
          'menu_item_id': item.item.id,
          'name': item.displayName,
          'quantity': item.quantity,
          'unit_price': item.effectivePrice,
          'total': item.total,
        }).toList(),
        'grand_total': cart.grandTotal,
      };

      final url = Uri.parse('http://$ip:$port/api/v1/restaurant/orders');
      debugPrint('📤 Submitting order to: $url');
      
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(orderData),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Success - clear cart and show confirmation
        cart.clear();
        cart.setTableNumber(null);
        cart.setCustomerNote(null);
        
        if (mounted) {
          _showOrderConfirmation();
        }
      } else {
        throw Exception('Order failed: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('❌ Error submitting order: $e');
      
      // Check if it's a network error — save offline if so
      final isNetworkError = e.toString().toLowerCase().contains('connection') ||
                             e.toString().toLowerCase().contains('socket') ||
                             e.toString().toLowerCase().contains('timeout') ||
                             e.toString().toLowerCase().contains('clientexception');
      
      if (isNetworkError && session.currentShopId != null) {
        try {
          final api = session.api;
          if (api == null) rethrow;
          await OrderService.createOrder(
            shopId: session.currentShopId!,
            items: cart.items,
            totalAmount: cart.grandTotal,
            apiService: api,
            module: 'restaurant',
          );
          
          cart.clear();
          cart.setTableNumber(null);
          cart.setCustomerNote(null);
          
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('⚠️ Shop unreachable. Order saved — will sync when online.'),
                backgroundColor: Colors.orange,
                duration: Duration(seconds: 4),
              ),
            );
            Navigator.pop(context);
          }
          return;
        } catch (offlineError) {
          debugPrint('❌ Offline save also failed: $offlineError');
        }
      }
      
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isSubmitting = false;
        });
      }
    }
  }

  void _showOrderConfirmation() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        icon: const Icon(Icons.check_circle, color: Colors.green, size: 64),
        title: const Text('Order Placed! 🎉'),
        content: const Text(
          'Your order has been sent to the kitchen.\n'
          'We\'ll start preparing it right away!',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context); // Back to menu
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Place Order'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Order summary card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.shopping_cart, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          'Order Summary',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        TextButton(
                          onPressed: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => CartScreen()),
                          ),
                          child: const Text('Edit'),
                        ),
                      ],
                    ),
                    const Divider(),
                    ...cart.items.map((item) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(
                        children: [
                          Text('${item.quantity}x'),
                          const SizedBox(width: 8),
                          Expanded(child: Text(item.displayName)),
                          Text(CurrencyFormatter.formatWithCurrency(item.total)),
                        ],
                      ),
                    )),
                    const Divider(),
                    Row(
                      children: [
                        Text(
                          'Total',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          CurrencyFormatter.formatWithCurrency(cart.grandTotal),
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: Colors.green[700],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 24),
            
            // Order type selection
            Text(
              'Order Type',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _OrderTypeCard(
                    type: OrderType.dineIn,
                    icon: Icons.table_restaurant,
                    label: 'Dine In',
                    isSelected: cart.orderType == OrderType.dineIn,
                    onTap: () => cart.setOrderType(OrderType.dineIn),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _OrderTypeCard(
                    type: OrderType.takeaway,
                    icon: Icons.takeout_dining,
                    label: 'Takeaway',
                    isSelected: cart.orderType == OrderType.takeaway,
                    onTap: () => cart.setOrderType(OrderType.takeaway),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 24),
            
            // Table number (for dine-in)
            if (cart.orderType == OrderType.dineIn) ...[
              TextFormField(
                controller: _tableController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Table Number',
                  hintText: 'Enter your table number',
                  prefixIcon: Icon(Icons.table_bar),
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your table number';
                  }
                  final num = int.tryParse(value);
                  if (num == null || num < 1) {
                    return 'Please enter a valid table number';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
            ],
            
            // Special instructions
            TextFormField(
              controller: _noteController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Special Instructions (Optional)',
                hintText: 'e.g., No onions, extra spicy...',
                prefixIcon: Icon(Icons.note),
                border: OutlineInputBorder(),
                alignLabelWithHint: true,
              ),
            ),
            
            const SizedBox(height: 32),
            
            // Error message
            if (_error != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Text(
                  _error!,
                  style: const TextStyle(color: Colors.red),
                  textAlign: TextAlign.center,
                ),
              ),
            
            // Submit button
            SizedBox(
              height: 56,
              child: ElevatedButton.icon(
                onPressed: _isSubmitting || cart.items.isEmpty ? null : _submitOrder,
                icon: _isSubmitting
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Icon(Icons.send),
                label: Text(
                  _isSubmitting ? 'Sending Order...' : 'Place Order',
                  style: const TextStyle(fontSize: 16),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// ORDER TYPE CARD
// ============================================================

class _OrderTypeCard extends StatelessWidget {
  final OrderType type;
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _OrderTypeCard({
    required this.type,
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: isSelected ? 4 : 1,
      color: isSelected ? Colors.green[50] : null,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isSelected ? Colors.green : Colors.grey[300]!,
          width: isSelected ? 2 : 1,
        ),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            children: [
              Icon(
                icon,
                size: 40,
                color: isSelected ? Colors.green : Colors.grey[600],
              ),
              const SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  color: isSelected ? Colors.green[700] : Colors.grey[700],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
import 'package:mbeck_go/services/receipt_service.dart';
import 'package:mbeck_go/database/app_database.dart';

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({super.key});

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  // Removed _frequentItems and _loyaltyPoints as requested
  List<Map<String, dynamic>> _notes = [];
  List<Receipt> _receipts = [];
  final TextEditingController _noteController = TextEditingController();
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    // Removed getFrequentItems and getAllPoints calls
    final notes = await ReceiptService.getNotes();
    final receipts = await ReceiptService.getHistory();
    if (mounted) {
      setState(() {
        _notes = notes;
        _receipts = receipts;
        _isLoading = false;
      });
    }
  }

  // ============= Analytics Calculations =============
  
  /// Most frequently visited shops (top 5)
  List<MapEntry<String, int>> get _topShops {
    final shopCounts = <String, int>{};
    for (final receipt in _receipts) {
      shopCounts[receipt.sellerName] = (shopCounts[receipt.sellerName] ?? 0) + 1;
    }
    final sorted = shopCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return sorted.take(5).toList();
  }
  
  /// Top 10 most expensive purchases
  List<Receipt> get _topExpensive {
    final sorted = List<Receipt>.from(_receipts)
      ..sort((a, b) => b.totalAmount.compareTo(a.totalAmount));
    return sorted.take(10).toList();
  }
  
  /// Common purchased items (extracted from itemsJson)
  List<MapEntry<String, int>> get _commonItems {
    final itemCounts = <String, int>{};
    for (final receipt in _receipts) {
      try {
        final List items = jsonDecode(receipt.itemsJson);
        for (final item in items) {
          final name = item['name'] as String? ?? 'Unknown';
          final qty = (item['quantity'] as num?)?.toInt() ?? 1;
          itemCounts[name] = (itemCounts[name] ?? 0) + qty;
        }
      } catch (e) {
        // ignore parse errors
      }
    }
    final sorted = itemCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return sorted.take(10).toList();
  }
  
  /// Calculate spending averages
  Map<String, double> get _spendingAverages {
    if (_receipts.isEmpty) {
      return {'weekly': 0, 'monthly': 0, 'yearly': 0};
    }
    
    final now = DateTime.now();
    final weekAgo = now.subtract(const Duration(days: 7));
    final monthAgo = now.subtract(const Duration(days: 30));
    final yearAgo = now.subtract(const Duration(days: 365));
    
    double weeklyTotal = 0;
    double monthlyTotal = 0;
    double yearlyTotal = 0;
    int weeklyCount = 0;
    int monthlyCount = 0;
    int yearlyCount = 0;
    
    for (final receipt in _receipts) {
      final date = receipt.timestamp;
      if (date.isAfter(weekAgo)) {
        weeklyTotal += receipt.totalAmount;
        weeklyCount++;
      }
      if (date.isAfter(monthAgo)) {
        monthlyTotal += receipt.totalAmount;
        monthlyCount++;
      }
      if (date.isAfter(yearAgo)) {
        yearlyTotal += receipt.totalAmount;
        yearlyCount++;
      }
    }
    
    return {
      'weekly': weeklyTotal,
      'monthly': monthlyTotal,
      'yearly': yearlyTotal,
      'weeklyAvg': weeklyCount > 0 ? weeklyTotal / weeklyCount : 0,
      'monthlyAvg': monthlyCount > 0 ? monthlyTotal / monthlyCount : 0,
      'yearlyAvg': yearlyCount > 0 ? yearlyTotal / yearlyCount : 0,
    };
  }

  Future<void> _addNote() async {
    if (_noteController.text.isEmpty) return;
    await ReceiptService.addNote(_noteController.text);
    _noteController.clear();
    _loadData();
  }

  Future<void> _toggleNote(int id, bool currentStatus) async {
    await ReceiptService.toggleNote(id, !currentStatus);
    _loadData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Smart Analysis', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : SingleChildScrollView(
            padding: const EdgeInsets.only(bottom: 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSpendingOverview(),
                
                const SizedBox(height: 24),
                
                _buildSectionHeader('🏪 Most Visited Shops'),
                _buildTopShops(),
                
                const SizedBox(height: 24),
                
                _buildSectionHeader('🛒 Common Purchases'),
                _buildCommonItems(),
                
                const SizedBox(height: 24),
                
                _buildSectionHeader('💰 Top 10 Expensive'),
                _buildTopExpensive(),

                // REMOVED: Loyalty Wallet and Frequent Buys as requested

                const SizedBox(height: 24),
                
                _buildSectionHeader('📝 Shopping List'),
                _buildAddNoteField(),
                _buildNotesList(),
              ],
            ),
          ),
    );
  }

  Widget _buildSpendingOverview() {
    final averages = _spendingAverages;
    
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF6A1B9A), Color(0xFFAB47BC)], // Deep Purple to Purple
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
           BoxShadow(color: Colors.purple.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 6)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Spending Overview',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: _buildSpendCard('This Week', averages['weekly'] ?? 0)),
              const SizedBox(width: 16),
              Expanded(child: _buildSpendCard('This Month', averages['monthly'] ?? 0)),
              const SizedBox(width: 16),
              Expanded(child: _buildSpendCard('This Year', averages['yearly'] ?? 0)),
            ],
          ),
          const SizedBox(height: 20),
          Container(
             padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
             decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
             ),
             child: Text(
              'Avg per purchase: ${CurrencyFormatter.formatWithCurrency(averages['monthlyAvg'] ?? 0)}',
              style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSpendCard(String label, double amount) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            'KES ${(amount / 1000).toStringAsFixed(1)}k', // Showing in K
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label, 
          style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12),
          overflow: TextOverflow.ellipsis,
          maxLines: 1,
        ),
      ],
    );
  }
  
  Widget _buildTopShops() {
    final shops = _topShops;
    if (shops.isEmpty) {
      return _buildEmptyHint('Visit shops to see your favorites!');
    }
    
    return SizedBox(
      height: 160, // Increased height to prevent vertical overflow
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: shops.length,
        itemBuilder: (context, index) {
          final shop = shops[index];
          return Container(
            width: 140,
            margin: const EdgeInsets.only(right: 12, bottom: 8),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                  BoxShadow(color: Colors.grey.withOpacity(0.1), blurRadius: 8, offset: const Offset(0, 4)),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                    backgroundColor: Colors.blue.shade50,
                    radius: 24,
                    child: Icon(Icons.store, color: Colors.blue.shade700),
                ),
                const SizedBox(height: 12),
                Text(
                  shop.key,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                const SizedBox(height: 4),
                Text('${shop.value} visits', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
              ],
            ),
          );
        },
      ),
    );
  }
  
  Widget _buildCommonItems() {
    final items = _commonItems;
    if (items.isEmpty) {
      return _buildEmptyHint('Make purchases to see common items!');
    }
    
    return SizedBox(
      height: 60,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          return Container(
            margin: const EdgeInsets.only(right: 12),
            child: Chip(
              elevation: 0,
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                  side: BorderSide(color: Colors.grey.shade200)
              ),
              avatar: CircleAvatar(
                backgroundColor: Colors.orange.shade100,
                child: Text('${item.value}', style: TextStyle(color: Colors.orange.shade800, fontSize: 10, fontWeight: FontWeight.bold)),
              ),
              label: Text(item.key, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
            ),
          );
        },
      ),
    );
  }
  
  Widget _buildTopExpensive() {
    final expensive = _topExpensive;
    if (expensive.isEmpty) {
      return _buildEmptyHint('No purchases yet!');
    }
    
    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: expensive.length,
      itemBuilder: (context, index) {
        final receipt = expensive[index];
        return Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(8)),
                  child: Text('#${index + 1}', style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.bold)),
              ),
              title: Text(
                receipt.sellerName, 
                style: const TextStyle(fontWeight: FontWeight.w600),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  'KES ${receipt.totalAmount}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
            ),
        );
      },
    );
  }
  
  Widget _buildEmptyHint(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade200) // Dashed border ideal but skipped
          ),
          child: Text(text, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade400))
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: -0.5)),
    );
  }

  Widget _buildAddNoteField() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4, offset: const Offset(0, 2))]
              ),
              child: TextField(
                controller: _noteController,
                decoration: const InputDecoration(
                  hintText: 'Add item (e.g. Milk, Eggs)',
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          FloatingActionButton.small(
            backgroundColor: Colors.black,
            onPressed: _addNote,
            elevation: 0,
            child: const Icon(Icons.add, color: Colors.white),
          )
        ],
      ),
    );
  }

  Widget _buildNotesList() {
    if (_notes.isEmpty) return const SizedBox.shrink();
    
    return Padding(
      padding: const EdgeInsets.only(top: 16, left: 16, right: 16),
      child: Container(
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
            children: _notes.map((note) {
              final isDone = (note['is_done'] as int) == 1;
              return Column(
                children: [
                  CheckboxListTile(
                    activeColor: Colors.black,
                    value: isDone,
                    title: Text(
                      note['content'],
                      style: TextStyle(
                        decoration: isDone ? TextDecoration.lineThrough : null,
                        color: isDone ? Colors.grey.shade400 : Colors.black87,
                      ),
                    ),
                    onChanged: (_) => _toggleNote(note['id'], isDone),
                  ),
                  if (note != _notes.last) const Divider(height: 1, indent: 16, endIndent: 16),
                ],
              );
            }).toList(),
        ),
      ),
    );
  }
}

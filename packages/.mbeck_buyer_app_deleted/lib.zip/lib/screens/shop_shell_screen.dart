import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../providers/shop_session_provider.dart';
import 'explore_feed_screen.dart';
import 'shop_home_screen.dart';
import 'orders_dashboard_screen.dart';
import 'profile_dashboard_screen.dart';
import 'inbox_screen.dart';

class ShopShellScreen extends StatefulWidget {
  const ShopShellScreen({super.key});

  @override
  State<ShopShellScreen> createState() => _ShopShellScreenState();
}

class _ShopShellScreenState extends State<ShopShellScreen> {
  int _currentIndex = 0;
  bool _wasConnected = false;

  Widget _buildActiveTab(int index) {
    switch (index) {
      case 0:
        return const ExploreFeedScreen();
      case 1:
        return const OrdersDashboardScreen(); 
      case 2:
        return const InboxScreen();
      case 3:
        return const ProfileDashboardScreen();
      default:
        return const SizedBox.shrink();
    }
  }

  void _openScanner() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => FractionallySizedBox(
        heightFactor: 0.85,
        child: Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Scan to Connect', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Text('Scan a table QR or shop entrance code to instantly enter the shop environment.', style: TextStyle(color: Colors.grey)),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  child: MobileScanner(
                    onDetect: (capture) {
                      final barcodes = capture.barcodes;
                      if (barcodes.isNotEmpty) {
                        Navigator.pop(ctx);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Scanned: ${barcodes.first.rawValue}')),
                        );
                      }
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<ShopSessionProvider>();
    final isConnected = session.isConnected;

    // When connected, we should push the Shop Environment screen, 
    // or if we stay in shell, show a global status.
    // For now, if connected, we push ShopHomeScreen onto the navigator stack 
    // so it overlays the shell completely.
    if (isConnected && !_wasConnected) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const ShopHomeScreen()),
          ).then((_) {
            // When returning, disconnect if needed
          });
        }
      });
    }
    _wasConnected = isConnected;

    return Scaffold(
      body: _buildActiveTab(_currentIndex),
      floatingActionButton: FloatingActionButton(
        onPressed: _openScanner,
        backgroundColor: Colors.black,
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: const Icon(Icons.qr_code_scanner, color: Colors.white),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex > 1 ? _currentIndex + 1 : _currentIndex,
        onDestinationSelected: (index) {
          if (index == 2) {
            _openScanner();
            return;
          }
          setState(() => _currentIndex = index > 2 ? index - 1 : index);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.explore_outlined),
            selectedIcon: Icon(Icons.explore),
            label: 'Explore',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'Orders',
          ),
          NavigationDestination(
            icon: SizedBox.shrink(),
            label: '', // Placeholder for FAB
          ),
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline),
            selectedIcon: Icon(Icons.chat_bubble),
            label: 'Inbox',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

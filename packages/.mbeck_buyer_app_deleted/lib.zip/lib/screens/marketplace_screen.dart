import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:provider/provider.dart';
import '../providers/shop_session_provider.dart';
import 'shop_shell_screen.dart';
import 'dart:convert';

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({super.key});

  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen> {
  final SupabaseClient _supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _shops = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchShops();
  }

  Future<void> _fetchShops() async {
    setState(() => _isLoading = true);
    try {
      final response = await _supabase
          .from('shops')
          .select()
          .eq('is_published_online', true)
          // .eq('verification_status', 'VERIFIED')
          .limit(20)
          .order('online_views', ascending: false);
          
      if (mounted) {
        setState(() {
          _shops = List<Map<String, dynamic>>.from(response);
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint('Failed to load marketplace shops: $e');
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load marketplace shops: $e')),
        );
      }
    }
  }

  Future<void> _connectToShop(String shopId, String shopName) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => const Center(
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('Entering shop...'),
              ],
            ),
          ),
        ),
      ),
    );

    final session = context.read<ShopSessionProvider>();
    final success = await session.connectToCloudShop(shopId, shopName);

    if (mounted) {
      Navigator.pop(context); // Close loading dialog
      if (success) {
        // Record shop view for analytics
        try {
          await _supabase.rpc('increment_shop_views', params: {'target_shop_id': shopId});
        } catch (_) {}
        
        try {
          await _supabase.rpc('log_analytics_event', params: {
            'p_event_name': 'MARKETPLACE_SHOP_OPENED',
            'p_platform': 'buyer',
            'p_shop_id': shopId,
            'p_details': {
              'shop_name': shopName,
            }
          });
        } catch (e) {
          debugPrint('⚠️ Failed to log analytics: $e');
        }
        
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const ShopShellScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to enter shop context. Please try again.')),
        );
      }
    }
  }

  Widget _buildShopCard(Map<String, dynamic> shop) {
    Map<String, dynamic> themeConfig = {};
    if (shop['theme_config'] != null) {
      if (shop['theme_config'] is String) {
        try { themeConfig = jsonDecode(shop['theme_config']); } catch (_) {}
      } else if (shop['theme_config'] is Map) {
        themeConfig = shop['theme_config'];
      }
    }
    
    // Also try checking the legacy branding field occasionally used
    if (themeConfig.isEmpty && shop['branding'] != null) {
      if (shop['branding'] is String) {
         try { themeConfig = jsonDecode(shop['branding']); } catch (_) {}
      } else if (shop['branding'] is Map) {
         themeConfig = shop['branding'];
      }
    }

    final coverImage = themeConfig['coverImageUrl'] as String? ?? '';
    final primaryHex = themeConfig['primaryColor'] as String?;
    final secondaryHex = themeConfig['secondaryColor'] as String?;
    
    Color primaryColor = Colors.purple;
    Color secondaryColor = Colors.deepPurple;
    
    if (primaryHex != null && primaryHex.isNotEmpty) {
      final hex = primaryHex.replaceAll('#', '');
      if (hex.length >= 6) {
        primaryColor = Color(int.parse(hex.substring(hex.length - 6), radix: 16) | 0xFF000000);
      }
    }
    
    if (secondaryHex != null && secondaryHex.isNotEmpty) {
      final hex2 = secondaryHex.replaceAll('#', '');
      if (hex2.length >= 6) {
        secondaryColor = Color(int.parse(hex2.substring(hex2.length - 6), radix: 16) | 0xFF000000);
      }
    }

    final shopName = shop['name'] ?? shop['business_name'] ?? 'Mbeck Shop';
    final views = shop['online_views'] ?? 0;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      clipBehavior: Clip.antiAlias,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: () => _connectToShop(shop['id'].toString(), shopName),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              height: 160,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (coverImage.isNotEmpty && (coverImage.startsWith('http') || coverImage.startsWith('https')))
                    Image.network(
                      coverImage,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(color: primaryColor),
                    )
                  else
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [primaryColor, secondaryColor],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: const Center(
                        child: Icon(Icons.storefront, size: 64, color: Colors.white54),
                      ),
                    ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Colors.black.withOpacity(0.8)],
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 16,
                    left: 16,
                    right: 16,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          shopName,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Icons.remove_red_eye, color: Colors.white70, size: 14),
                            const SizedBox(width: 4),
                            Text(
                              '$views views',
                              style: const TextStyle(color: Colors.white70, fontSize: 13),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                  Positioned(
                    top: 12,
                    right: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.verified, color: primaryColor, size: 16),
                          const SizedBox(width: 4),
                          Text(
                            'Verified',
                            style: TextStyle(
                              color: primaryColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mbeck Marketplace'),
        backgroundColor: Colors.purple,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _fetchShops,
          )
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _shops.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.cloud_off, size: 80, color: Colors.grey.shade400),
                      const SizedBox(height: 16),
                      Text(
                        'No shops available online',
                        style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Check back later for newly published storefronts.',
                        style: TextStyle(color: Colors.grey.shade500),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  itemCount: _shops.length,
                  itemBuilder: (context, index) {
                    return _buildShopCard(_shops[index]);
                  },
                ),
    );
  }
}

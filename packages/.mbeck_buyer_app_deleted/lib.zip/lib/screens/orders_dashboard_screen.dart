import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/starred_provider.dart';
import '../providers/cart_provider.dart';
import '../providers/shop_session_provider.dart';
import 'starred_items_screen.dart';
import 'buyer_checkout_screen.dart';

class OrdersDashboardScreen extends StatefulWidget {
  const OrdersDashboardScreen({super.key});

  @override
  State<OrdersDashboardScreen> createState() => _OrdersDashboardScreenState();
}

class _OrdersDashboardScreenState extends State<OrdersDashboardScreen> {
  Timer? _pollingTimer;
  List<dynamic> _activeOrders = [];
  bool _isLoadingOrders = true;

  @override
  void initState() {
    super.initState();
    _startPolling();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    super.dispose();
  }

  void _startPolling() {
    _fetchActiveOrders();
    _pollingTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _fetchActiveOrders();
    });
  }

  Future<void> _fetchActiveOrders() async {
    if (!mounted) return;
    final session = context.read<ShopSessionProvider>();
    if (!session.isConnected || session.api == null) {
      if (mounted) {
        setState(() {
          _activeOrders = [];
          _isLoadingOrders = false;
        });
      }
      return;
    }

    try {
      final response = await session.api!.getActiveOrders();
      if (mounted) {
        setState(() {
          _activeOrders = response['orders'] ?? [];
          _isLoadingOrders = false;
        });
      }
    } catch (e) {
      debugPrint('Failed to poll active orders: $e');
      if (mounted) {
        setState(() {
          _isLoadingOrders = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final starred = context.watch<StarredProvider>();
    final cart = context.watch<CartProvider>();

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: const Text('My Orders', style: TextStyle(fontWeight: FontWeight.bold)),
        elevation: 0,
      ),
      body: CustomScrollView(
        slivers: [
          // Active Orders Section (Live Table Orders, etc.)
          SliverToBoxAdapter(
            child: _buildSection(
              title: 'Active Orders',
              child: _isLoadingOrders && _activeOrders.isEmpty
                  ? const Center(child: CircularProgressIndicator())
                  : _activeOrders.isEmpty
                      ? _buildEmptyState('No active orders right now', Icons.receipt_long)
                      : _buildActiveOrdersList(),
            ),
          ),
          
          // Cart Section
          SliverToBoxAdapter(
            child: _buildSection(
              title: 'My Cart',
              action: cart.itemCount > 0 ? TextButton(
                onPressed: () => cart.clear(),
                child: const Text('Clear', style: TextStyle(color: Colors.red)),
              ) : null,
              child: cart.itemCount == 0 
                ? _buildEmptyState('Your cart is empty', Icons.shopping_cart_outlined)
                : _buildCartSummary(context, cart),
            ),
          ),

          // Starred Items Section
          SliverToBoxAdapter(
            child: _buildSection(
              title: 'Starred Items',
              action: starred.count > 0 ? TextButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StarredItemsScreen())),
                child: const Text('View All'),
              ) : null,
              child: starred.count == 0 
                ? _buildEmptyState('No starred items yet', Icons.star_border)
                : _buildStarredSummary(context, starred),
            ),
          ),

          // Past Orders Section
          SliverToBoxAdapter(
            child: _buildSection(
              title: 'Purchase History',
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: Column(
                  children: [
                    Icon(Icons.history_rounded, size: 36, color: Colors.grey.shade400),
                    const SizedBox(height: 10),
                    Text('View your full purchase history', style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.w500)),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () => Navigator.pushNamed(context, '/receipts'),
                      icon: const Icon(Icons.receipt_long_outlined, size: 16),
                      label: const Text('Open Receipts'),
                    ),
                  ],
                ),
              ),
            ),
          ),
          
          const SliverPadding(padding: EdgeInsets.only(bottom: 100)),
        ],
      ),
    );
  }

  Widget _buildSection({required String title, Widget? action, required Widget child}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              if (action != null) action,
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _buildEmptyState(String message, IconData icon) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: [
          Icon(icon, size: 32, color: Colors.grey.shade400),
          const SizedBox(height: 12),
          Text(message, style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildActiveOrdersList() {
    return Column(
      children: _activeOrders.map((order) {
        final status = order['status'] ?? 'pending';
        final total = order['total'] ?? 0.0;
        final orderNumber = order['order_number'] ?? order['id'].toString().substring(0, 8);
        
        Color statusColor;
        IconData statusIcon;
        switch (status) {
          case 'preparing':
            statusColor = Colors.orange;
            statusIcon = Icons.soup_kitchen;
            break;
          case 'ready':
            statusColor = Colors.green;
            statusIcon = Icons.check_circle;
            break;
          case 'served':
          case 'completed':
            statusColor = Colors.blue;
            statusIcon = Icons.done_all;
            break;
          default: // pending
            statusColor = Colors.grey.shade600;
            statusIcon = Icons.schedule;
        }

        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.grey.shade200),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10, offset: const Offset(0, 4)),
            ],
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            leading: CircleAvatar(
              backgroundColor: statusColor.withOpacity(0.1),
              child: Icon(statusIcon, color: statusColor),
            ),
            title: Text('Order #$orderNumber', style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(
              'Status: ${status.toString().toUpperCase()}',
              style: TextStyle(color: statusColor, fontWeight: FontWeight.w600, fontSize: 12),
            ),
            trailing: Text('\$${total.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildCartSummary(BuildContext context, CartProvider cart) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        children: [
          ...cart.items.map((item) => ListTile(
            title: Text(item.displayName, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text('Qty: ${item.quantity}'),
            trailing: Text('\$${item.total.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
          )),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Total:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                Text('\$${cart.grandTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const BuyerCheckoutScreen()),
                  );
                },
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('Checkout', style: TextStyle(fontSize: 16)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStarredSummary(BuildContext context, StarredProvider starred) {
    final items = starred.items.take(3).toList();
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        children: items.map((item) => ListTile(
          leading: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(8),
              image: item.imagePath != null && item.imagePath!.isNotEmpty
                  ? DecorationImage(image: NetworkImage(item.imagePath!), fit: BoxFit.cover)
                  : null,
            ),
            child: item.imagePath == null || item.imagePath!.isEmpty
                ? Icon(Icons.fastfood, color: Colors.grey.shade400)
                : null,
          ),
          title: Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text(item.shopName, maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: Text('\$${item.price.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
        )).toList(),
      ),
    );
  }
}


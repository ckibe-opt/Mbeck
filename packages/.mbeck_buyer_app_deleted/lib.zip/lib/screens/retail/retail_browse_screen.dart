import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../providers/starred_provider.dart';
import '../../providers/shop_session_provider.dart';
import '../../providers/cart_provider.dart';
import '../../renderers/design_registry.dart';
import '../cart_screen.dart';

/// Retail product browsing screen for buyer app.
/// Uses the active ModuleDesign to render all UI elements.
/// Buyers can star items, view business contact, and add products to cart.
class RetailBrowseScreen extends StatefulWidget {
  const RetailBrowseScreen({super.key});

  @override
  State<RetailBrowseScreen> createState() => _RetailBrowseScreenState();
}

class _RetailBrowseScreenState extends State<RetailBrowseScreen> {
  List<InventoryItem> _items = [];
  List<String> _categories = [];
  String _selectedCategory = 'All';
  String _searchQuery = '';
  bool _isLoading = true;
  String? _error;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadInventory();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadInventory() async {
    setState(() { _isLoading = true; _error = null; });
    
    final session = context.read<ShopSessionProvider>();
    final api = session.api;
    if (api == null) {
      setState(() { _error = 'Not connected'; _isLoading = false; });
      return;
    }

    try {
      final items = await api.getInventory();
      
      final cats = <String>{'All'};
      for (final item in items) {
        if (item.category != null && item.category!.isNotEmpty) {
          cats.add(item.category!);
        }
      }
      
      if (mounted) {
        setState(() {
          _items = items;
          _categories = cats.toList()..sort();
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() { _error = e.toString(); _isLoading = false; });
    }
  }

  List<InventoryItem> get _filteredItems {
    var items = _items;
    if (_selectedCategory != 'All') {
      items = items.where((i) => i.category == _selectedCategory).toList();
    }
    if (_searchQuery.isNotEmpty) {
      items = items.where((i) => i.name.toLowerCase().contains(_searchQuery.toLowerCase())).toList();
    }
    return items;
  }

  int get _inStockCount => _items.where((i) => i.stock > 0).length;

  /// Get the active design for this module
  ModuleDesign _getDesign() {
    final session = context.read<ShopSessionProvider>();
    final themeConfig = session.currentShopTheme;
    final designId = themeConfig?.designForModule('retail') ?? 'clean_standard';
    return DesignRegistry.resolve(designId);
  }

  void _handleCall() async {
    final session = context.read<ShopSessionProvider>();
    final phone = session.currentShopTheme?.phoneNumber;
    if (phone == null || phone.isEmpty) return;
    final uri = Uri.parse('tel:$phone');
    final launched = await canLaunchUrl(uri) && await launchUrl(uri);
    if (!launched && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Call the shop: $phone'),
          action: SnackBarAction(label: 'Copy', onPressed: () {}),
          duration: const Duration(seconds: 5),
        ),
      );
    }
  }

  void _handleDirections() async {
    final session = context.read<ShopSessionProvider>();
    final config = session.currentShopTheme;
    Uri? uri;
    if (config?.latitude != null && config?.longitude != null) {
      uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=${config!.latitude},${config.longitude}');
    } else if (config?.locationAddress != null) {
      uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(config!.locationAddress!)}');
    }
    if (uri == null) return;
    final launched = await canLaunchUrl(uri) && await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Address: ${config?.locationAddress ?? 'Not available'}')),
      );
    }
  }

  /// Adds an item to the cart and shows a confirmation snackbar.
  void _addToCart(InventoryItem item) {
    if (item.stock <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${item.name} is out of stock'),
          backgroundColor: Colors.orange.shade700,
          duration: const Duration(seconds: 2),
        ),
      );
      return;
    }
    final cart = context.read<CartProvider>();
    cart.addItem(item);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text('${item.name} added to cart')),
          ],
        ),
        duration: const Duration(seconds: 2),
        action: SnackBarAction(
          label: 'View Cart',
          textColor: Colors.amber,
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CartScreen()),
          ),
        ),
      ),
    );
  }

  void _showItemDetails(InventoryItem item) {
    final session = context.read<ShopSessionProvider>();
    final starred = context.read<StarredProvider>();
    final shopId = session.currentShopId ?? '';
    final shopName = session.currentShopName ?? 'Shop';
    
    final designId = session.currentShopTheme?.designForModule('retail') ?? 'clean_standard';
    final design = DesignRegistry.resolve(designId);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Stack(
        children: [
          design.buildItemDetailSheet(
            context,
            item: {
              'name': item.name,
              'price': item.sellingPrice,
              'image_path': item.imagePath,
              'description': item.specification,
              'category': item.category,
              'stock': item.stock,
            },
            isStarred: starred.isStarred(item.id.toString(), shopId),
            onStar: () => starred.toggle(
              id: item.id.toString(),
              name: item.name,
              module: 'retail',
              price: item.sellingPrice,
              imagePath: item.imagePath,
              category: item.category,
              description: item.specification,
              shopId: shopId,
              shopName: shopName,
            ),
            phoneNumber: session.currentShopTheme?.phoneNumber,
            locationAddress: session.currentShopTheme?.locationAddress,
            onCall: _handleCall,
            onDirections: _handleDirections,
          ),
          // ── "Add to Cart" action bar at sheet bottom ──────────
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: FilledButton.icon(
                  onPressed: item.stock > 0
                      ? () {
                          Navigator.pop(ctx);
                          _addToCart(item);
                        }
                      : null,
                  icon: const Icon(Icons.add_shopping_cart),
                  label: Text(
                    item.stock > 0
                        ? 'Add to Cart  •  ${CurrencyFormatter.formatWithCurrency(item.sellingPrice)}'
                        : 'Out of Stock',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                  style: FilledButton.styleFrom(
                    minimumSize: const Size.fromHeight(52),
                    backgroundColor: item.stock > 0 ? null : Colors.grey.shade400,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    final session = context.watch<ShopSessionProvider>();
    final starred = context.watch<StarredProvider>();
    final design = _getDesign();
    final shopId = session.currentShopId ?? '';
    final shopName = session.currentShopName ?? 'Shop';
    final starredCount = starred.forShop(shopId).where((s) => s.module == 'retail').length;

    final immersiveBody = design.buildImmersiveBody(

      context,
      module: 'retail',
      shopName: shopName,
      items: _items,
      categories: _categories,
      selectedCategory: _selectedCategory,
      onCategorySelected: (cat) => setState(() => _selectedCategory = cat),
      searchQuery: _searchQuery,
      onSearchChanged: (v) => setState(() => _searchQuery = v),
      isLoading: _isLoading,
      onRefresh: _loadInventory,
      itemRenderer: (item) {
        return design.buildRetailProductCard(
          context,
          item: {
            'name': item.name,
            'price': item.sellingPrice,
            'image_path': item.imagePath,
            'stock': item.stock,
            'category': item.category,
            'description': item.specification,
          },
          isStarred: starred.isStarred(item.id.toString(), shopId),
          onStar: () => starred.toggle(
            id: item.id.toString(),
            name: item.name,
            module: 'retail',
            price: item.sellingPrice,
            imagePath: item.imagePath,
            category: item.category,
            description: item.specification,
            shopId: shopId,
            shopName: shopName,
          ),
          onTap: () => _showItemDetails(item),
        );
      },
    );

    return Scaffold(
      appBar: immersiveBody != null ? null : AppBar(

        title: const Text('Shop'),
        actions: [
          if (starredCount > 0)
            Stack(
              children: [
                IconButton(
                  icon: const Icon(Icons.star_outlined),
                  tooltip: 'Starred Items',
                  onPressed: () => _showStarredSheet(),
                ),
                Positioned(
                  right: 4, top: 4,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(color: Colors.amber, shape: BoxShape.circle),
                    constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                    child: Text('$starredCount', style: const TextStyle(color: Colors.black, fontSize: 10, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                  ),
                ),
              ],
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _buildErrorState()
              : immersiveBody ?? (_items.isEmpty
                  ? _buildEmptyState()
                  : RefreshIndicator(

                      onRefresh: _loadInventory,
                      child: CustomScrollView(
                        slivers: [
                          // Hero
                          SliverToBoxAdapter(child: design.buildRetailHero(
                            context,
                            itemCount: _inStockCount,
                            categoryCount: _categories.length - 1,
                            shopName: shopName,
                          )),
                          // Search
                          SliverToBoxAdapter(child: design.buildSearchBar(
                            context,
                            controller: _searchController,
                            onChanged: (v) => setState(() => _searchQuery = v),
                            hint: 'Search products...',
                          )),
                          // Categories
                          if (_categories.length > 2)
                            SliverToBoxAdapter(child: design.buildCategoryNav(
                              context,
                              categories: _categories,
                              selected: _selectedCategory,
                              onSelect: (cat) => setState(() => _selectedCategory = cat),
                            )),
                          // Results count
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: Text(
                                '${_filteredItems.length} product${_filteredItems.length == 1 ? '' : 's'}',
                                style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.w500, fontSize: 14),
                              ),
                            ),
                          ),
                          // Products grid
                          _filteredItems.isEmpty
                              ? SliverFillRemaining(
                                  hasScrollBody: false,
                                  child: Center(child: Text('No products match your search', style: TextStyle(color: Colors.grey.shade500))),
                                )
                              : SliverPadding(
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                  sliver: SliverGrid(
                                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      childAspectRatio: 0.72,
                                      crossAxisSpacing: 10,
                                      mainAxisSpacing: 10,
                                    ),
                                    delegate: SliverChildBuilderDelegate(
                                      (context, i) {
                                        final item = _filteredItems[i];
                                        return design.buildRetailProductCard(
                                          context,
                                          item: {
                                            'name': item.name,
                                            'price': item.sellingPrice,
                                            'image_path': item.imagePath,
                                            'stock': item.stock,
                                            'category': item.category,
                                            'description': item.specification,
                                          },
                                          isStarred: starred.isStarred(item.id.toString(), shopId),
                                          onStar: () => starred.toggle(
                                            id: item.id.toString(),
                                            name: item.name,
                                            module: 'retail',
                                            price: item.sellingPrice,
                                            imagePath: item.imagePath,
                                            category: item.category,
                                            description: item.specification,
                                            shopId: shopId,
                                            shopName: shopName,
                                          ),
                                          onTap: () => _showItemDetails(item),
                                        );
                                      },
                                      childCount: _filteredItems.length,
                                    ),
                                  ),
                                ),
                          const SliverToBoxAdapter(child: SizedBox(height: 24)),
                        ],
                      ),
                    )),

      bottomNavigationBar: design.buildContactBar(
        context,
        shopName: shopName,
        phoneNumber: session.currentShopTheme?.phoneNumber,
        locationAddress: session.currentShopTheme?.locationAddress,
        onCall: _handleCall,
        onDirections: _handleDirections,
      ),
      floatingActionButton: Consumer<CartProvider>(
        builder: (context, cart, _) {
          if (cart.itemCount == 0) return const SizedBox.shrink();
          return FloatingActionButton.extended(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const CartScreen()),
            ),
            icon: const Icon(Icons.shopping_cart),
            label: Text('${cart.itemCount} item${cart.itemCount == 1 ? '' : 's'}  •  ${CurrencyFormatter.formatWithCurrency(cart.grandTotal)}'),
            backgroundColor: Theme.of(context).colorScheme.primary,
            foregroundColor: Colors.white,
          );
        },
      ),
    );
  }

  void _showStarredSheet() {
    final starred = context.read<StarredProvider>();
    final session = context.read<ShopSessionProvider>();
    final shopId = session.currentShopId ?? '';
    final shopStarred = starred.forShop(shopId).where((s) => s.module == 'retail').toList();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        minChildSize: 0.3,
        maxChildSize: 0.85,
        expand: false,
        builder: (ctx, scrollController) => Column(
          children: [
            // Handle
            Padding(
              padding: const EdgeInsets.only(top: 12, bottom: 8),
              child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: Row(
                children: [
                  const Icon(Icons.star, color: Colors.amber, size: 24),
                  const SizedBox(width: 8),
                  Text('Starred Items (${shopStarred.length})', style: Theme.of(ctx).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                controller: scrollController,
                padding: const EdgeInsets.all(16),
                itemCount: shopStarred.length,
                itemBuilder: (ctx, i) {
                  final item = shopStarred[i];
                  return Dismissible(
                    key: ValueKey(item.id),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 20),
                      color: Colors.red,
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    onDismissed: (_) => starred.remove(item.id, item.shopId),
                    child: ListTile(
                      leading: Container(
                        width: 48, height: 48,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: item.imagePath != null
                            ? Image.network(item.imagePath!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.shopping_bag_outlined))
                            : const Icon(Icons.shopping_bag_outlined),
                      ),
                      title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text(CurrencyFormatter.formatWithCurrency(item.price)),
                      trailing: Icon(Icons.star, color: Colors.amber, size: 20),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.cloud_off, size: 64, color: Colors.red.shade200),
            const SizedBox(height: 16),
            Text('Could not load products', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey.shade700)),
            const SizedBox(height: 8),
            Text(_error!, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade500)),
            const SizedBox(height: 24),
            FilledButton.icon(onPressed: _loadInventory, icon: const Icon(Icons.refresh), label: const Text('Retry')),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.inventory_2_outlined, size: 64, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text('No products available', style: TextStyle(fontSize: 16, color: Colors.grey.shade600)),
          const SizedBox(height: 8),
          Text('This shop hasn\'t added products yet', style: TextStyle(color: Colors.grey.shade400)),
        ],
      ),
    );
  }
}



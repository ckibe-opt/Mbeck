import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/shop_session_provider.dart';
import '../providers/cart_provider.dart';
import '../screens/inbox_screen.dart';
import '../screens/buyer_checkout_screen.dart';
import 'restaurant/restaurant_menu_screen.dart';
import 'services/service_browse_screen.dart';
import 'entertainment/entertainment_browse_screen.dart';
import 'lodging/lodging_browse_screen.dart';
import 'retail/retail_browse_screen.dart';

class ShopHomeScreen extends StatefulWidget {
  const ShopHomeScreen({super.key});

  @override
  State<ShopHomeScreen> createState() => _ShopHomeScreenState();
}

class _ShopHomeScreenState extends State<ShopHomeScreen> {
  @override
  Widget build(BuildContext context) {
    final session = context.watch<ShopSessionProvider>();
    final modules = session.enabledModules ?? ['retail'];

    // Single-module shop: go directly to that module screen
    if (modules.length == 1) {
      return _buildModuleScreen(modules.first);
    }

    // Multi-module shop: Use a TabBar view for seamless switching
    return Consumer<CartProvider>(builder: (context, cart, _) {
      return DefaultTabController(
        length: modules.length,
        child: Scaffold(
          appBar: AppBar(
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  session.currentShopName ?? 'Shop',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const Text('Powered by Mbeck', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w400, letterSpacing: 0.5)),
              ],
            ),
            elevation: 0,
            scrolledUnderElevation: 2,
            actions: [
              // Cart badge
              Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.shopping_cart_outlined),
                    tooltip: 'Cart',
                    onPressed: cart.itemCount > 0
                        ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BuyerCheckoutScreen()))
                        : null,
                  ),
                  if (cart.itemCount > 0)
                    Positioned(
                      right: 4, top: 4,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                        constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                        child: Text('${cart.itemCount}', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                      ),
                    ),
                ],
              ),
              // Chat shortcut
              IconButton(
                icon: const Icon(Icons.chat_bubble_outline),
                tooltip: 'Chat with Shop',
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InboxScreen())),
              ),
              // Disconnect
              IconButton(
                icon: const Icon(Icons.exit_to_app),
                tooltip: 'Leave Shop',
                onPressed: () => session.disconnect(),
              ),
            ],
            bottom: TabBar(
              isScrollable: true,
              indicatorWeight: 3,
              labelStyle: const TextStyle(fontWeight: FontWeight.bold),
              tabs: modules.map((m) {
                final config = _moduleConfig(m);
                return Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(config.icon, size: 18),
                      const SizedBox(width: 8),
                      Text(config.label),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
          body: TabBarView(
            children: modules.map((m) => _buildModuleScreen(m)).toList(),
          ),
        ),
      );
    });
  }

  Widget _buildModuleScreen(String module) {
    switch (module) {
      case 'restaurant':
        return const RestaurantMenuScreen();
      case 'services':
        return const ServiceBrowseScreen();
      case 'entertainment':
        return const EntertainmentBrowseScreen();
      case 'lodging':
        return const LodgingBrowseScreen();
      case 'retail':
      default:
        return const RetailBrowseScreen();
    }
  }

  _ModuleConfig _moduleConfig(String module) {
    switch (module) {
      case 'restaurant':
        return _ModuleConfig(icon: Icons.restaurant, label: 'Dining');
      case 'services':
        return _ModuleConfig(icon: Icons.spa, label: 'Services');
      case 'entertainment':
        return _ModuleConfig(icon: Icons.sports_esports, label: 'Fun');
      case 'lodging':
        return _ModuleConfig(icon: Icons.hotel, label: 'Stays');
      case 'retail':
      default:
        return _ModuleConfig(icon: Icons.storefront, label: 'Shop');
    }
  }
}

class _ModuleConfig {
  final IconData icon;
  final String label;
  const _ModuleConfig({required this.icon, required this.label});
}


import 'package:flutter/material.dart';
import 'package:mbeck_go/services/database_service.dart';
import 'package:drift/drift.dart' as drift;
import 'package:mbeck_go/database/app_database.dart';
import 'package:mbeck_go/services/loyalty_service.dart';
import 'package:mbeck_go/widgets/loyalty_card.dart';
import 'package:mbeck_go/widgets/receipt_widget.dart';
import 'settings_screen.dart';
import 'scan_receipt_screen.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  final _db = DatabaseService.instance.db;
  late Stream<List<Receipt>> _receiptStream;
  List<LoyaltyData> _loyaltyCards = [];
  bool _isLoadingLoyalty = true;

  @override
  void initState() {
    super.initState();
    // Watch receipts for real-time updates
    _receiptStream = (_db.select(_db.receipts)
          ..orderBy([(t) => drift.OrderingTerm.desc(t.timestamp)]))
        .watch();
        
    // Listen to stream to calculate loyalty
    _receiptStream.listen((receipts) {
       _calculateLoyalty(receipts);
    });
  }

  void _calculateLoyalty(List<Receipt> receipts) {
    if (!mounted) return;
    
    setState(() {
      _loyaltyCards = LoyaltyService.instance.calculateDeepLoyalty(receipts);
      _isLoadingLoyalty = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: const Text('Loyalty Score', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.black),
            onPressed: () {
               Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 1. Loyalty Carousel
           SizedBox(
            height: 240, 
            child: _isLoadingLoyalty 
                ? const Center(child: CircularProgressIndicator())
                : _loyaltyCards.isEmpty
                  ? _buildEmptyLoyaltyState()
                  : PageView.builder(
                      controller: PageController(viewportFraction: 0.9),
                      itemCount: _loyaltyCards.length,
                      itemBuilder: (context, index) {
                        return LoyaltyCard(data: _loyaltyCards[index]);
                      },
                    ),
          ),
          
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: Text(
              'Recent Receipts',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          
          Expanded(
            child: StreamBuilder<List<Receipt>>(
              stream: _receiptStream,
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final receipts = snapshot.data!;
                if (receipts.isEmpty) {
                  return _buildEmptyState();
                }
                
                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  itemCount: receipts.length,
                  itemBuilder: (context, index) {
                    return ReceiptWidget(
                        receipt: receipts[index],
                        onTap: () {
                          // View details
                        },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
            // Trigger QR Scanner
             await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ScanReceiptScreen()),
              );
        },
        backgroundColor: Colors.black,
        icon: const Icon(Icons.qr_code_scanner, color: Colors.white,),
        label: const Text('Scan & Go', style: TextStyle(color: Colors.white)),
      ),
    );
  }

  Widget _buildEmptyLoyaltyState() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade300,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
             Icon(Icons.stars, size: 48, color: Colors.grey),
             SizedBox(height: 8),
             Text("No loyalty points yet", style: TextStyle(color: Colors.black54)),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.history, size: 64, color: Colors.grey[300]),
        const SizedBox(height: 16),
        const Text(
          'No receipts yet',
          style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
        const SizedBox(height: 8),
        const Text(
          'Scan a shop QR code to start buying!',
          style: TextStyle(color: Colors.grey),
        ),
      ],
    );
  }
}

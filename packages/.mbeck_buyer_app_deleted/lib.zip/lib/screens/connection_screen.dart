import 'dart:convert';
import 'dart:io';
import 'package:bonsoir/bonsoir.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../providers/shop_session_provider.dart';
import 'shop_home_screen.dart';
import 'global_search_screen.dart';
import 'history_screen.dart';
import 'marketplace_screen.dart';



class ConnectionScreen extends StatefulWidget {
  const ConnectionScreen({super.key});

  @override
  State<ConnectionScreen> createState() => _ConnectionScreenState();
}

class _ConnectionScreenState extends State<ConnectionScreen> {
  // Cache for shop preview info (image URL, business type, theme colors)
  final Map<String, Map<String, dynamic>> _shopPreviewCache = {};

  @override
  void initState() {
    super.initState();
    // Start scanning immediately when screen loads
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ShopSessionProvider>().startDiscovery();
    });
  }

  /// Fetch preview info (image, modules, theme) for a discovered shop
  Future<Map<String, dynamic>?> _fetchShopPreview(BonsoirService shop) async {
    final cacheKey = '${shop.host}:${shop.port}';
    if (_shopPreviewCache.containsKey(cacheKey)) {
      return _shopPreviewCache[cacheKey];
    }

    try {
      final host = shop.host ?? 'localhost';
      // Resolve hostname
      String ip = host;
      try {
        final ips = await InternetAddress.lookup(host);
        if (ips.isNotEmpty) ip = ips.first.address;
      } catch (_) {}

      final url = Uri.parse('http://$ip:${shop.port}/api/v1/info');
      final response = await http.get(url).timeout(const Duration(seconds: 3));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        _shopPreviewCache[cacheKey] = data;
        return data;
      }
    } catch (e) {
      debugPrint('Preview fetch failed for ${shop.name}: $e');
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ShopSessionProvider>();
    final shops = provider.discoveredShops;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Connect to Shop'),
        actions: [
          IconButton(
            icon: const Icon(Icons.storefront),
            tooltip: 'Marketplace',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MarketplaceScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.search),
            tooltip: 'Global Search',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const GlobalSearchScreen()),
              );
            },
          ),

          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'History',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const HistoryScreen()),
              );
            },
          ),
          IconButton(
            icon: provider.isScanning 
                ? const Icon(Icons.refresh) 
                : const Icon(Icons.play_arrow),
            tooltip: provider.isScanning ? 'Refresh' : 'Start Scan',
            onPressed: () {
              if (provider.isScanning) {
                provider.stopDiscovery();
                Future.delayed(const Duration(milliseconds: 500), () {
                  if (context.mounted) provider.startDiscovery();
                });
              } else {
                provider.startDiscovery();
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Scanning Status Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              border: Border(
                bottom: BorderSide(color: Colors.green.shade200),
              ),
            ),
            child: Row(
              children: [
                if (provider.isScanning)
                  const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                else
                  Icon(Icons.wifi_off, color: Colors.grey.shade600),
                const SizedBox(width: 12),
                Text(
                  provider.isScanning
                      ? 'Scanning for local shops...'
                      : 'Tap refresh to scan',
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: Colors.grey.shade800,
                  ),
                ),
              ],
            ),
          ),
          
          // Shop List
          Expanded(
            child: shops.isEmpty
                ? _buildEmptyState(provider)
                : _buildShopList(shops, provider),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showManualConnectDialog(context),
        icon: const Icon(Icons.login),
        label: const Text('Manual IP'),
      ),
    );
  }

  /// Empty state when no shops found
  Widget _buildEmptyState(ShopSessionProvider provider) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          const SizedBox(height: 40),
          Icon(
            Icons.store_outlined,
            size: 80,
            color: Colors.grey.shade300,
          ),
          const SizedBox(height: 20),
          Text(
            'No shops found',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Colors.grey.shade700,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Connect to seller\'s WiFi to start shopping',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 32),
          
          // WiFi Connection Steps
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.green.shade200),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.wifi, color: Colors.green.shade700),
                    const SizedBox(width: 8),
                    Text(
                      'How to Connect',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.green.shade800,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _buildConnectionStep('1', 'Ask seller for WiFi QR code'),
                _buildConnectionStep('2', 'Scan QR with your phone camera'),
                _buildConnectionStep('3', 'Connect to the WiFi network'),
                _buildConnectionStep('4', 'Return here and tap "Scan Again"'),
              ],
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Network info
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: Colors.blue.shade700, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'This is a local connection only. No internet access.',
                    style: TextStyle(
                      color: Colors.blue.shade800,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          ElevatedButton.icon(
            onPressed: provider.startDiscovery,
            icon: const Icon(Icons.refresh),
            label: const Text('Scan Again'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(
                horizontal: 32,
                vertical: 16,
              ),
            ),
          ),
          const SizedBox(height: 16),

        ],
      ),
    );
  }
  
  Widget _buildConnectionStep(String number, String text) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        children: [
          Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: Colors.green.shade600,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                number,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            text,
            style: TextStyle(color: Colors.green.shade900, fontSize: 13),
          ),
        ],
      ),
    );
  }

  /// Shop list with cards
  Widget _buildShopList(List<BonsoirService> shops, ShopSessionProvider provider) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: shops.length,
      itemBuilder: (context, index) {
        final shop = shops[index];
        final category = shop.attributes['type'] ?? 'General';
        
        return _buildShopCard(
          shopName: shop.name,
          category: category,
          shop: shop,
          provider: provider,
        );
      },
    );
  }

  /// Modern shop discovery card with image preview and theme identity
  Widget _buildShopCard({
    required String shopName,
    required String category,
    required BonsoirService shop,
    required ShopSessionProvider provider,
  }) {
    return FutureBuilder<Map<String, dynamic>?>(
      future: _fetchShopPreview(shop),
      builder: (context, snapshot) {
        final info = snapshot.data;
        final shopImageUrl = info?['shopImageUrl'] as String?;
        final businessType = info?['businessType'] as String? ?? category;
        final themeData = info?['theme'] as Map<String, dynamic>?;

        // Extract theme colors for card styling
        Color primaryColor = Colors.green;
        Color secondaryColor = Colors.green.shade700;
        if (themeData != null) {
          try {
            final pc = themeData['primary_color'];
            if (pc is String && pc.isNotEmpty) {
              final hex = pc.replaceAll('#', '');
              if (hex.length >= 6) {
                primaryColor = Color(int.parse(hex.substring(hex.length - 6), radix: 16) | 0xFF000000);
              }
            }
            final sc = themeData['secondary_color'];
            if (sc is String && sc.isNotEmpty) {
              final hex2 = sc.replaceAll('#', '');
              if (hex2.length >= 6) {
                secondaryColor = Color(int.parse(hex2.substring(hex2.length - 6), radix: 16) | 0xFF000000);
              }
            }
          } catch (_) {}
        }

        // Module icon
        IconData moduleIcon = Icons.store;
        String moduleLabel = 'Retail';
        if (businessType == 'restaurant') {
          moduleIcon = Icons.restaurant;
          moduleLabel = 'Restaurant';
        } else if (businessType == 'services') {
          moduleIcon = Icons.design_services;
          moduleLabel = 'Services';
        }

        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          clipBehavior: Clip.antiAlias,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 3,
          shadowColor: primaryColor.withOpacity(0.2),
          child: InkWell(
            onTap: () => _connectToShop(shop, provider),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Shop image banner / gradient header
                SizedBox(
                  height: 120,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      // Background: image or gradient
                      if (shopImageUrl != null && shopImageUrl.isNotEmpty)
                        Image.network(
                          shopImageUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [primaryColor, secondaryColor],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                            child: Center(
                              child: Icon(moduleIcon, size: 48, color: Colors.white54),
                            ),
                          ),
                        )
                      else
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [primaryColor, secondaryColor],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                          child: Center(
                            child: Icon(moduleIcon, size: 48, color: Colors.white54),
                          ),
                        ),
                      // Overlay gradient for text readability
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.5),
                            ],
                          ),
                        ),
                      ),
                      // Shop name on image
                      Positioned(
                        bottom: 12,
                        left: 16,
                        right: 16,
                        child: Text(
                          shopName,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            shadows: [Shadow(blurRadius: 4, color: Colors.black38)],
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      // Online indicator
                      Positioned(
                        top: 10,
                        right: 10,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.green,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.circle, size: 8, color: Colors.white),
                              SizedBox(width: 4),
                              Text('Online', style: TextStyle(
                                color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600,
                              )),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Bottom info bar
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      // Module badge
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: primaryColor.withOpacity(0.3)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(moduleIcon, size: 14, color: primaryColor),
                            const SizedBox(width: 4),
                            Text(
                              moduleLabel,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: primaryColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (themeData?['style_preset'] != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            (themeData!['style_preset'] as String).toUpperCase(),
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: Colors.grey.shade600,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                      const Spacer(),
                      // Connect button
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          color: primaryColor,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('Connect', style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            )),
                            SizedBox(width: 4),
                            Icon(Icons.arrow_forward, color: Colors.white, size: 16),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Connect to discovered shop
  Future<void> _connectToShop(
    BonsoirService shop,
    ShopSessionProvider provider,
  ) async {
    // Show loading
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => const Center(
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('Connecting...'),
              ],
            ),
          ),
        ),
      ),
    );

    final success = await provider.connectToShop(shop);

    if (mounted) {
      Navigator.pop(context); // Close loading

      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Connected to ${shop.name}!'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const ShopHomeScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Connection failed. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Manual IP connection dialog
  void _showManualConnectDialog(BuildContext context) {
    final ipController = TextEditingController();
    final portController = TextEditingController(text: '8080');

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Connect Manually'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Enter the IP address shown on the Seller App',
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: ipController,
              decoration: const InputDecoration(
                labelText: 'IP Address',
                hintText: '192.168.1.5',
                prefixIcon: Icon(Icons.wifi),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: portController,
              decoration: const InputDecoration(
                labelText: 'Port',
                hintText: '8080',
                prefixIcon: Icon(Icons.settings_ethernet),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final ip = ipController.text.trim();
              final port = int.tryParse(portController.text.trim()) ?? 8080;
              
              if (ip.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please enter an IP address')),
                );
                return;
              }

              Navigator.pop(dialogContext); // Close dialog
              
              // Show loading
              showDialog(
                context: context,
                barrierDismissible: false,
                builder: (ctx) => const Center(
                  child: Card(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircularProgressIndicator(),
                          SizedBox(height: 16),
                          Text('Connecting...'),
                        ],
                      ),
                    ),
                  ),
                ),
              );

              final provider = context.read<ShopSessionProvider>();
              final success = await provider.connectToShopByIp(
                ip,
                port,
                "Manual Shop",
              );

              if (mounted) {
                Navigator.pop(context); // Close loading

                if (success) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Connected to $ip!'),
                      backgroundColor: Colors.green,
                    ),
                  );
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ShopHomeScreen()),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Connection failed. Check IP and port.'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: const Text('Connect'),
          ),
        ],
      ),
    );
  }
}

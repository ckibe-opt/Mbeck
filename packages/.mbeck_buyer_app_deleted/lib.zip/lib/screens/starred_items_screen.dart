import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
import '../providers/starred_provider.dart';

/// Screen showing all starred/bookmarked items across shops and modules.
class StarredItemsScreen extends StatelessWidget {
  const StarredItemsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final starred = context.watch<StarredProvider>();
    final items = starred.items;
    final theme = Theme.of(context);

    // Group by shop
    final Map<String, List<StarredItem>> grouped = {};
    for (final item in items) {
      grouped.putIfAbsent(item.shopName, () => []).add(item);
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Starred Items'),
        actions: [
          if (items.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              tooltip: 'Clear All',
              onPressed: () => _showClearDialog(context, starred),
            ),
        ],
      ),
      body: items.isEmpty
          ? _buildEmptyState()
          : ListView.builder(
              padding: const EdgeInsets.only(top: 8, bottom: 24),
              itemCount: grouped.keys.length,
              itemBuilder: (context, i) {
                final shopName = grouped.keys.elementAt(i);
                final shopItems = grouped[shopName]!;
                return _buildShopSection(context, shopName, shopItems, starred, theme);
              },
            ),
    );
  }

  Widget _buildShopSection(
    BuildContext context,
    String shopName,
    List<StarredItem> items,
    StarredProvider starred,
    ThemeData theme,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Row(
            children: [
              Icon(Icons.storefront, size: 18, color: theme.primaryColor),
              const SizedBox(width: 8),
              Text(shopName, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: theme.primaryColor)),
              const Spacer(),
              Text('${items.length} item${items.length == 1 ? '' : 's'}', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
            ],
          ),
        ),
        ...items.map((item) => Dismissible(
          key: ValueKey('${item.id}_${item.shopId}'),
          direction: DismissDirection.endToStart,
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 20),
            color: Colors.red.shade400,
            child: const Icon(Icons.delete, color: Colors.white),
          ),
          onDismissed: (_) {
            starred.remove(item.id, item.shopId);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('${item.name} removed'),
                duration: const Duration(seconds: 2),
                action: SnackBarAction(label: 'Undo', onPressed: () {
                  starred.toggle(
                    id: item.id,
                    name: item.name,
                    module: item.module,
                    price: item.price,
                    imagePath: item.imagePath,
                    shopId: item.shopId,
                    shopName: item.shopName,
                  );
                }),
              ),
            );
          },
          child: _buildItemTile(context, item, theme),
        )),
        const Divider(indent: 16, endIndent: 16),
      ],
    );
  }

  Widget _buildItemTile(BuildContext context, StarredItem item, ThemeData theme) {
    final moduleIcons = {
      'retail': Icons.shopping_bag_outlined,
      'restaurant': Icons.restaurant_outlined,
      'services': Icons.content_cut,
      'entertainment': Icons.sports_esports,
      'lodging': Icons.hotel_outlined,
    };

    return ListTile(
      leading: Container(
        width: 52, height: 52,
        decoration: BoxDecoration(
          color: Colors.grey.shade100,
          borderRadius: BorderRadius.circular(10),
        ),
        clipBehavior: Clip.antiAlias,
        child: item.imagePath != null && item.imagePath!.isNotEmpty
            ? Image.network(item.imagePath!, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Icon(moduleIcons[item.module] ?? Icons.star, color: Colors.grey.shade400))
            : Icon(moduleIcons[item.module] ?? Icons.star, color: Colors.grey.shade400),
      ),
      title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Row(
        children: [
          Text(CurrencyFormatter.formatWithCurrency(item.price), style: TextStyle(color: theme.primaryColor, fontWeight: FontWeight.w500)),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(item.module.toUpperCase(), style: TextStyle(fontSize: 9, color: Colors.grey.shade600, letterSpacing: 0.5, fontWeight: FontWeight.w500)),
          ),
        ],
      ),
      trailing: const Icon(Icons.star, color: Colors.amber, size: 20),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.star_border, size: 72, color: Colors.amber.shade200),
            const SizedBox(height: 24),
            Text('No starred items yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey.shade700)),
            const SizedBox(height: 8),
            Text(
              'Browse shops and star items you\'re interested in.\nThey\'ll appear here for easy access.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey.shade500, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }

  void _showClearDialog(BuildContext context, StarredProvider starred) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear All Starred?'),
        content: Text('Remove all ${starred.count} starred items?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              starred.clearAll();
              Navigator.pop(ctx);
            },
            child: const Text('Clear All'),
          ),
        ],
      ),
    );
  }
}

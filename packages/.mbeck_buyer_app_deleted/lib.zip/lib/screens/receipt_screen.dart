import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/app_database.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
class ReceiptScreen extends StatefulWidget {
  final Receipt receipt;

  const ReceiptScreen({super.key, required this.receipt});

  @override
  State<ReceiptScreen> createState() => _ReceiptScreenState();
}

class _ReceiptScreenState extends State<ReceiptScreen> {
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _decodeItems();
  }
  
  void _decodeItems() {
    try {
      final List decoded = jsonDecode(widget.receipt.itemsJson);
      _items = decoded.cast<Map<String, dynamic>>();
    } catch (e) {
      debugPrint('Error decoding receipt items: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final date = widget.receipt.timestamp;
    final total = widget.receipt.totalAmount;
    final shopName = widget.receipt.sellerName;
    final receiptId = widget.receipt.id;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Receipt Details'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code),
            tooltip: 'Show QR',
            onPressed: () => _showQrDialog(context),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'share') _shareReceipt();
              if (value == 'whatsapp') _shareViaWhatsApp();
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'share', child: ListTile(leading: Icon(Icons.share), title: Text('Share'))),
              const PopupMenuItem(value: 'whatsapp', child: ListTile(leading: Icon(Icons.chat), title: Text('WhatsApp'))),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Shop Header
            Center(
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.storefront, size: 48, color: Colors.green),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    shopName,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    DateFormat.yMMMd().add_jm().format(date),
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                  if (widget.receipt.module != null) ...[
                    const SizedBox(height: 8),
                    Chip(
                      avatar: Icon(_moduleIcon(widget.receipt.module), size: 16),
                      label: Text(_moduleLabel(widget.receipt.module)),
                      visualDensity: VisualDensity.compact,
                    ),
                  ],
                  const SizedBox(height: 4),
                  Text(
                    'Receipt #$receiptId',
                    style: TextStyle(color: Colors.grey.shade400, fontSize: 12),
                  ),
                ],
              ),
            ),
            const Divider(height: 48),

            // Items List
            const Text(
              'Items Purchased',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final item = _items[index];
                final price = (item['price'] as num).toDouble();
                final quantity = (item['quantity'] as num).toInt();
                
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        '${quantity}x',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item['name'] ?? item['item_name'] ?? 'Item',
                            style: const TextStyle(fontWeight: FontWeight.w500),
                          ),
                          if (item['category'] != null)
                            Text(
                              item['category'],
                              style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                            ),
                        ],
                      ),
                    ),
                    Text(
                      CurrencyFormatter.formatWithCurrency(price * quantity),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ],
                );
              },
            ),

            const Divider(height: 48),

            // Total
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Total Paid',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Text(
                  CurrencyFormatter.formatWithCurrency(total),
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.green),
                ),
              ],
            ),
            
            const SizedBox(height: 48),

            // Decorative Check
            Center(
               child: Column(
                 children: [
                   Icon(Icons.check_circle_outline, size: 64, color: Colors.green.shade300),
                   const SizedBox(height: 8),
                   Text(
                     'Transaction Completed',
                     style: TextStyle(color: Colors.green.shade700, fontWeight: FontWeight.bold),
                   ),
                 ],
               ),
            ),

            // Notes (if any)
            if (widget.receipt.notes != null && widget.receipt.notes!.isNotEmpty) ...[
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.amber.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.amber.shade200),
                ),
                child: Row(
                  children: [
                    Icon(Icons.sticky_note_2, color: Colors.amber.shade700, size: 20),
                    const SizedBox(width: 8),
                    Expanded(child: Text(widget.receipt.notes!, style: TextStyle(color: Colors.amber.shade900))),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _receiptText() {
    final r = widget.receipt;
    final lines = <String>[
      '🧾 Receipt from ${r.sellerName}',
      'Date: ${DateFormat.yMMMd().add_jm().format(r.timestamp)}',
      if (r.module != null) 'Type: ${_moduleLabel(r.module)}',
      '---',
    ];
    for (final item in _items) {
      final name = item['name'] ?? item['item_name'] ?? 'Item';
      final qty = (item['quantity'] as num).toInt();
      final price = (item['price'] as num).toDouble();
      lines.add('${qty}x $name — ${CurrencyFormatter.formatWithCurrency(price * qty)}');
    }
    lines.addAll([
      '---',
      'Total: ${CurrencyFormatter.formatWithCurrency(r.totalAmount)}',
      if (r.notes != null && r.notes!.isNotEmpty) 'Notes: ${r.notes}',
      'Receipt #${r.id}',
    ]);
    return lines.join('\n');
  }

  void _shareReceipt() {
    SharePlus.instance.share(ShareParams(text: _receiptText()));
  }

  Future<void> _shareViaWhatsApp() async {
    final text = Uri.encodeComponent(_receiptText());
    final url = Uri.parse('https://wa.me/?text=$text');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  void _showQrDialog(BuildContext context) {
    final qrData = jsonEncode({
      's': widget.receipt.sellerName,
      't': widget.receipt.totalAmount,
      'd': widget.receipt.timestamp.millisecondsSinceEpoch,
      'id': widget.receipt.id,
      if (widget.receipt.module != null) 'm': widget.receipt.module,
    });

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Receipt QR'),
        content: SizedBox(
          width: 250,
          height: 250,
          child: QrImageView(
            data: qrData,
            size: 250,
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
      ),
    );
  }

  String _moduleLabel(String? module) {
    switch (module) {
      case 'restaurant': return 'Restaurant';
      case 'services': return 'Services';
      case 'entertainment': return 'Entertainment';
      case 'lodging': return 'Lodging';
      case 'retail': return 'Retail';
      default: return 'Purchase';
    }
  }

  IconData _moduleIcon(String? module) {
    switch (module) {
      case 'restaurant': return Icons.restaurant;
      case 'services': return Icons.build_circle;
      case 'entertainment': return Icons.sports_esports;
      case 'lodging': return Icons.hotel;
      case 'retail': return Icons.shopping_bag;
      default: return Icons.receipt;
    }
  }
}

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../../providers/shop_session_provider.dart';
import '../../services/shop_discovery_service.dart';
import '../../widgets/buyer_ui_components.dart';
import '../marketplace_screen.dart';

class ShopDiscoveryView extends StatefulWidget {
  const ShopDiscoveryView({super.key});

  @override
  State<ShopDiscoveryView> createState() => _ShopDiscoveryViewState();
}

class _ShopDiscoveryViewState extends State<ShopDiscoveryView> {
  List<DiscoveredShop> _discoveredShops = [];
  bool _isScanning = false;

  @override
  void initState() {
    super.initState();
    _scanForShops();
  }

  Future<void> _scanForShops() async {
    if (!mounted) return;
    setState(() => _isScanning = true);

    try {
      final shops = await ShopDiscoveryService.discoverShops(
        timeout: const Duration(seconds: 4),
      );

      if (mounted) {
        setState(() {
          _discoveredShops = shops;
          _isScanning = false;
        });
        // Fetch preview info for each shop
        _fetchShopPreviews(shops);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isScanning = false);
        debugPrint('Scan error: $e');
      }
    }
  }

  /// Fetch preview info (modules, business type, cover image) for discovered shops
  Future<void> _fetchShopPreviews(List<DiscoveredShop> shops) async {
    for (final shop in shops) {
      try {
        final url = Uri.parse('http://${shop.ip}:${shop.port}/api/v1/info');
        final response = await http.get(url).timeout(const Duration(seconds: 3));
        if (response.statusCode == 200) {
          final json = jsonDecode(response.body);
          shop.businessType = json['businessType'] as String?;
          shop.enabledModules = List<String>.from(json['enabledModules'] ?? []);
          shop.shopImageUrl = json['shopImageUrl'] as String?;
          shop.theme = json['theme'] as Map<String, dynamic>?;
          if (mounted) setState(() {});
        }
      } catch (e) {
        debugPrint('Failed to fetch preview for ${shop.name}: $e');
      }
    }
  }

  Future<void> _connectToShop(DiscoveredShop shop) async {
    final provider = context.read<ShopSessionProvider>();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Center(
        child: Card(
          margin: const EdgeInsets.all(32),
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 20),
                Text('Connecting to ${shop.name}...', style: const TextStyle(fontWeight: FontWeight.w500)),
              ],
            ),
          ),
        ),
      ),
    );

    final success = await provider.connectToShopByIp(shop.ip, shop.port, shop.name);

    if (!mounted) return;
    Navigator.pop(context);

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(children: [const Icon(Icons.check_circle, color: Colors.white), const SizedBox(width: 12), Text('Connected to ${shop.name}')]),
          backgroundColor: BuyerAppColors.success,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(children: [Icon(Icons.error_outline, color: Colors.white), SizedBox(width: 12), Text('Connection failed. Check WiFi signal.')]),
          backgroundColor: Colors.red.shade600,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  /// Scan WiFi QR code to get network credentials and connect
  void _openWifiQrScanner() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => FractionallySizedBox(
        heightFactor: 0.75,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.qr_code_scanner, size: 28),
                  const SizedBox(width: 8),
                  const Text('Scan WiFi QR Code', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Spacer(),
                  IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text('Point your camera at the QR code posted at the shop entrance', style: TextStyle(color: Colors.grey)),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: MobileScanner(
                    onDetect: (capture) {
                      final barcodes = capture.barcodes;
                      if (barcodes.isEmpty) return;
                      final code = barcodes.first.rawValue;
                      if (code == null) return;

                      Navigator.pop(ctx);

                      if (code.startsWith('WIFI:')) {
                        _parseAndShowWifiCredentials(code);
                      } else {
                        // Might be a direct shop connection QR
                        _handleDirectShopQr(code);
                      }
                    },
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  /// Handle a direct shop QR: {"ip": "...", "port": 8080, "name": "Feroz"}
  void _handleDirectShopQr(String code) {
    try {
      final json = jsonDecode(code) as Map<String, dynamic>;
      final ip = json['ip'] as String?;
      final port = (json['port'] as num?)?.toInt() ?? 8080;
      final name = json['name'] as String? ?? 'Shop';

      if (ip != null) {
        _connectToShop(DiscoveredShop(name: name, ip: ip, port: port));
        return;
      }
    } catch (_) {}

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Unrecognized QR code format')),
    );
  }

  /// Parse WiFi QR format: WIFI:T:WPA;S:NetworkName;P:Password;;
  void _parseAndShowWifiCredentials(String code) {
    String? ssid;
    String? password;

    final params = code.replaceFirst('WIFI:', '').split(';');
    for (final param in params) {
      if (param.startsWith('S:')) ssid = param.substring(2);
      if (param.startsWith('P:')) password = param.substring(2);
    }

    if (ssid == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invalid WiFi QR code')));
      return;
    }

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: const Icon(Icons.wifi, size: 48, color: Colors.teal),
        title: Text('Connect to "$ssid"'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _wifiField('Network', ssid!),
            if (password != null && password.isNotEmpty) _wifiField('Password', password),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(8)),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, size: 16, color: Colors.blue),
                  SizedBox(width: 8),
                  Expanded(child: Text('Connect to this WiFi in your phone settings, then come back and tap "Scan for Shops".', style: TextStyle(fontSize: 12, color: Colors.blue))),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton.icon(
            onPressed: () { Navigator.pop(ctx); _scanForShops(); },
            icon: const Icon(Icons.wifi_find),
            label: const Text('Scan for Shops'),
          ),
        ],
      ),
    );
  }

  Widget _wifiField(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SizedBox(width: 80, child: Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 13))),
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(6)),
              child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontFamily: 'monospace')),
            ),
          ),
        ],
      ),
    );
  }

  IconData _moduleIcon(String module) {
    switch (module) {
      case 'restaurant': return Icons.restaurant;
      case 'services': return Icons.spa;
      case 'entertainment': return Icons.sports_esports;
      case 'lodging': return Icons.hotel;
      case 'retail': return Icons.storefront;
      default: return Icons.store;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return RefreshIndicator(
      onRefresh: _scanForShops,
      color: theme.primaryColor,
      child: CustomScrollView(
        slivers: [
          // Header
          SliverToBoxAdapter(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [theme.primaryColor, theme.primaryColor.withOpacity(0.85)],
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                ),
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Discover', style: theme.textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 4),
                            Text('Find shops nearby on WiFi', style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 14)),
                          ],
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(12)),
                        child: IconButton(
                          icon: _isScanning
                              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                              : const Icon(Icons.refresh, color: Colors.white),
                          tooltip: 'Scan for Shops',
                          onPressed: _isScanning ? null : _scanForShops,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // QR Scanner — Prominent
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Card(
                elevation: 4,
                shadowColor: Colors.teal.withOpacity(0.3),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: InkWell(
                  onTap: _openWifiQrScanner,
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: LinearGradient(colors: [Colors.teal.shade600, Colors.teal.shade400]),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(14)),
                          child: const Icon(Icons.qr_code_scanner, size: 28, color: Colors.white),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Scan QR Code', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 4),
                              Text('Scan the WiFi QR at the shop entrance', style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 13)),
                            ],
                          ),
                        ),
                        const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 18),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Cloud Marketplace — Prominent
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Card(
                elevation: 4,
                shadowColor: Colors.purple.withOpacity(0.3),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: InkWell(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MarketplaceScreen())),
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: LinearGradient(colors: [Colors.purple.shade600, Colors.purple.shade400]),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(14)),
                          child: const Icon(Icons.public, size: 28, color: Colors.white),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Global Marketplace', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 4),
                              Text('Browse verified online stores instantly', style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 13)),
                            ],
                          ),
                        ),
                        const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 18),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // Nearby Shops header
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  Icon(Icons.wifi_tethering, color: theme.primaryColor, size: 20),
                  const SizedBox(width: 8),
                  Text('Nearby Shops', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const Spacer(),
                  if (_discoveredShops.isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: BuyerAppColors.success.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                      child: Text('${_discoveredShops.length} found', style: const TextStyle(color: BuyerAppColors.success, fontWeight: FontWeight.w600, fontSize: 12)),
                    ),
                ],
              ),
            ),
          ),

          // Shop list or states
          if (_isScanning && _discoveredShops.isEmpty)
            SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 80, height: 80,
                      child: CircularProgressIndicator(strokeWidth: 3, color: theme.primaryColor),
                    ),
                    const SizedBox(height: 24),
                    Text('Scanning nearby networks...', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    Text('Looking for Mbeck shops on your WiFi', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                  ],
                ),
              ),
            )
          else if (_discoveredShops.isEmpty)
            SliverFillRemaining(child: _buildEmptyState())
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) => _buildEnhancedShopCard(_discoveredShops[index]),
                childCount: _discoveredShops.length,
              ),
            ),

          const SliverPadding(padding: EdgeInsets.only(bottom: 100)),
        ],
      ),
    );
  }

  /// Enhanced shop card showing modules, cover image, business type
  Widget _buildEnhancedShopCard(DiscoveredShop shop) {
    final modules = shop.enabledModules ?? [];
    final hasPreview = modules.isNotEmpty;

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _connectToShop(shop),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Cover image if available
            if (shop.shopImageUrl != null && shop.shopImageUrl!.isNotEmpty)
              SizedBox(
                height: 100,
                width: double.infinity,
                child: Image.network(
                  shop.shopImageUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    height: 100,
                    color: Theme.of(context).primaryColor.withOpacity(0.1),
                    child: Icon(Icons.storefront, size: 40, color: Theme.of(context).primaryColor.withOpacity(0.3)),
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Shop icon
                  Container(
                    width: 48, height: 48,
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.storefront, color: Theme.of(context).primaryColor),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(shop.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const OnlineStatusBadge(isOnline: true),
                            if (shop.businessType != null) ...[
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(4)),
                                child: Text(shop.businessType!, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w500)),
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                ],
              ),
            ),
            // Module badges (Feroz scenario: restaurant + entertainment + retail)
            if (hasPreview && modules.length > 1)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Wrap(
                  spacing: 6, runSpacing: 4,
                  children: modules.map((m) => Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(color: Theme.of(context).primaryColor.withOpacity(0.08), borderRadius: BorderRadius.circular(8)),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(_moduleIcon(m), size: 14, color: Theme.of(context).primaryColor),
                        const SizedBox(width: 4),
                        Text(_moduleLabel(m), style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Theme.of(context).primaryColor)),
                      ],
                    ),
                  )).toList(),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _moduleLabel(String module) {
    switch (module) {
      case 'restaurant': return 'Restaurant';
      case 'services': return 'Services';
      case 'entertainment': return 'Entertainment';
      case 'lodging': return 'Lodging';
      case 'retail': return 'Shop';
      default: return module;
    }
  }

  Widget _buildEmptyState() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(color: BuyerAppColors.gray100, shape: BoxShape.circle),
              child: const Icon(Icons.wifi_off_rounded, size: 48, color: BuyerAppColors.gray400),
            ),
            const SizedBox(height: 24),
            const Text('No shops found nearby', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: BuyerAppColors.gray900)),
            const SizedBox(height: 8),
            const Text('Make sure you\'re on the same WiFi\nnetwork as the seller', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: BuyerAppColors.gray600)),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: _isScanning ? null : _scanForShops,
              icon: const Icon(Icons.refresh),
              label: const Text('Scan Again'),
              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: _openWifiQrScanner,
              icon: const Icon(Icons.qr_code_scanner),
              label: const Text('Scan WiFi QR Code'),
            ),
          ],
        ),
      ),
    );
  }
}

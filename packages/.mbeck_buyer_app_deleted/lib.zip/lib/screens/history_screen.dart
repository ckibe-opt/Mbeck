import 'package:flutter/material.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
import 'package:intl/intl.dart';
import 'package:mbeck_go/services/receipt_service.dart';
import 'package:mbeck_go/screens/analysis_screen.dart';
import 'package:mbeck_go/database/app_database.dart';
import 'receipt_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Receipt> _receipts = [];
  bool _isLoading = true;
  String? _selectedShopFilter; // null = show all shops
  
  // Filters
  DateTimeRange? _dateRange;
  double? _minPrice;
  double? _maxPrice;
  
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final data = await ReceiptService.getHistory();
    if (mounted) {
      setState(() {
        _receipts = data;
        _isLoading = false;
      });
    }
  }

  /// Group receipts by shop name for the drawer
  Map<String, List<Receipt>> get _receiptsByShop {
    final map = <String, List<Receipt>>{};
    for (final receipt in _receipts) {
      map.putIfAbsent(receipt.sellerName, () => []).add(receipt);
    }
    return map;
  }

  /// Filtered receipts based on selected shop, date and price
  List<Receipt> get _filteredReceipts {
    final filtered = _receipts.where((r) {
      // Shop filter
      if (_selectedShopFilter != null && r.sellerName != _selectedShopFilter) return false;
      
      // Date filter
      if (_dateRange != null) {
        if (r.timestamp.isBefore(_dateRange!.start) || r.timestamp.isAfter(_dateRange!.end.add(const Duration(days: 1)))) {
          return false;
        }
      }
      
      // Price filter
      if (_minPrice != null && r.totalAmount < _minPrice!) return false;
      if (_maxPrice != null && r.totalAmount > _maxPrice!) return false;
      
      return true;
    }).toList();

    // Sort by most recent first
    filtered.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    return filtered;
  }

  Map<String, List<Receipt>> _groupReceiptsByDate(List<Receipt> receipts) {
    final Map<String, List<Receipt>> groups = {};
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));

    for (var receipt in receipts) {
      final date = DateTime(receipt.timestamp.year, receipt.timestamp.month, receipt.timestamp.day);
      String key;
      if (date == today) {
        key = 'Today';
      } else if (date == yesterday) {
        key = 'Yesterday';
      } else {
        key = DateFormat('MMMM d, y').format(date);
      }
      
      if (!groups.containsKey(key)) {
        groups[key] = [];
      }
      groups[key]!.add(receipt);
    }
    return groups;
  }

  void _clearFilters() {
    setState(() {
      _selectedShopFilter = null;
      _dateRange = null;
      _minPrice = null;
      _maxPrice = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final filtered = _filteredReceipts;
    
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Colors.black),
          tooltip: 'Filter by Shop',
          onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        ),
        title: Text(
          _selectedShopFilter ?? 'Purchase History',
          style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.analytics_outlined, color: Colors.black),
            tooltip: 'Smart Analysis',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AnalysisScreen()),
              );
            },
          ),
        ],
      ),
      drawer: _buildShopDrawer(theme),
      body: Column(
        children: [
          _buildFilterBar(),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : filtered.isEmpty
                    ? _buildEmptyState()
                    : _buildReceiptList(filtered),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterBar() {
    bool hasActiveFilters = _dateRange != null || _minPrice != null || _maxPrice != null || _selectedShopFilter != null;

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                // Date Filter Chip
                FilterChip(
                  label: Text(_dateRange == null 
                    ? 'All Dates' 
                    : '${DateFormat.yMMMd().format(_dateRange!.start)} - ${DateFormat.yMMMd().format(_dateRange!.end)}'),
                  selected: _dateRange != null,
                  onSelected: (_) => _selectDateRange(),
                ),
                const SizedBox(width: 8),
                // Price Filter Chip
                FilterChip(
                  label: Text(_minPrice == null && _maxPrice == null 
                    ? 'Any Price' 
                    : '${_minPrice != null ? CurrencyFormatter.formatWithCurrency(_minPrice!) : 'KES 0'} - ${_maxPrice != null ? CurrencyFormatter.formatWithCurrency(_maxPrice!) : 'Any'}'),
                  selected: _minPrice != null || _maxPrice != null,
                  onSelected: (_) => _showPriceFilterDialog(),
                ),
                if (hasActiveFilters) ...[
                  const SizedBox(width: 8),
                  TextButton.icon(
                    onPressed: _clearFilters,
                    icon: const Icon(Icons.clear_all, size: 18),
                    label: const Text('Clear'),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _selectDateRange() async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2023),
      lastDate: DateTime.now(),
      initialDateRange: _dateRange,
    );
    if (picked != null) {
      setState(() => _dateRange = picked);
    }
  }

  void _showPriceFilterDialog() {
    final minController = TextEditingController(text: _minPrice?.toStringAsFixed(0));
    final maxController = TextEditingController(text: _maxPrice?.toStringAsFixed(0));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Filter by Price'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: minController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Min Price (KES)', prefixText: 'KES '),
            ),
            TextField(
              controller: maxController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Max Price (KES)', prefixText: 'KES '),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                _minPrice = null;
                _maxPrice = null;
              });
              Navigator.pop(context);
            },
            child: const Text('Clear'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _minPrice = double.tryParse(minController.text);
                _maxPrice = double.tryParse(maxController.text);
              });
              Navigator.pop(context);
            },
            child: const Text('Apply'),
          ),
        ],
      ),
    );
  }

  /// Drawer with shop-grouped navigation
  Widget _buildShopDrawer(ThemeData theme) {
    final shopGroups = _receiptsByShop;
    
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Colors.black87, Colors.black54],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.store, color: Colors.white, size: 32),
                  const SizedBox(height: 12),
                  const Text(
                    'Shops Visited',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '${shopGroups.length} shops • ${_receipts.length} receipts',
                    style: TextStyle(color: Colors.white.withOpacity(0.9)),
                  ),
                ],
              ),
            ),
            
            // All Shops option
            ListTile(
              leading: const Icon(Icons.all_inclusive),
              title: const Text('All Shops'),
              selected: _selectedShopFilter == null,
              onTap: () {
                setState(() => _selectedShopFilter = null);
                Navigator.pop(context);
              },
            ),
            const Divider(),
            
            // Shop list
            Expanded(
              child: ListView.builder(
                itemCount: shopGroups.length,
                itemBuilder: (context, index) {
                  final shopName = shopGroups.keys.elementAt(index);
                  final receipts = shopGroups[shopName]!;
                  final totalSpent = receipts.fold<double>(
                    0.0, (sum, r) => sum + r.totalAmount,
                  );
                  
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.grey[200],
                      child: Text(
                        shopName.isNotEmpty ? shopName[0].toUpperCase() : '?',
                        style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                      ),
                    ),
                    title: Text(shopName, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('${receipts.length} visits • ${CurrencyFormatter.formatWithCurrency(totalSpent)}'),
                    selected: _selectedShopFilter == shopName,
                    onTap: () {
                      setState(() => _selectedShopFilter = shopName);
                      Navigator.pop(context);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReceiptList(List<Receipt> receipts) {
    final groups = _groupReceiptsByDate(receipts);
    final items = <dynamic>[];
    groups.forEach((key, list) {
      items.add(key); // Header
      items.addAll(list);
    });

    return RefreshIndicator(
      onRefresh: _loadHistory,
      child: ListView.separated(
        padding: const EdgeInsets.only(bottom: 100),
        itemCount: items.length,
        separatorBuilder: (context, index) {
          if (items[index] is String || (index + 1 < items.length && items[index+1] is String)) {
            return const SizedBox.shrink();
          }
          return Divider(height: 1, color: Colors.grey.shade200, indent: 72);
        },
        itemBuilder: (context, index) {
          final item = items[index];
          
          if (item is String) {
            return _buildDateHeader(item);
          }
          
          final receipt = item as Receipt;
          return _buildTransactionRow(receipt);
        },
      ),
    );
  }

  Widget _buildDateHeader(String date) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        date.toUpperCase(),
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: Colors.grey.shade600,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildTransactionRow(Receipt receipt) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ReceiptScreen(receipt: receipt)),
        );
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            // Icon
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.shopping_bag_outlined, color: Colors.green),
            ),
            const SizedBox(width: 16),
            
            // Details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    receipt.sellerName,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    DateFormat('HH:mm').format(receipt.timestamp),
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
            
            // Amount
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  'KSH ${receipt.totalAmount}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    receipt.signature.length > 8 ? receipt.signature.substring(0, 8).toUpperCase() : receipt.signature.toUpperCase(),
                    style: TextStyle(
                      color: Colors.blue.shade700,
                      fontSize: 10,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    bool isSearching = _dateRange != null || _minPrice != null || _maxPrice != null || _selectedShopFilter != null;
    
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isSearching ? Icons.search_off : Icons.receipt_long_outlined, 
            size: 80, 
            color: Colors.grey.shade300
          ),
          const SizedBox(height: 24),
          Text(
            isSearching ? 'No results found' : 'No purchases yet',
            style: TextStyle(
              fontSize: 20, 
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            isSearching 
              ? 'Try adjusting your filters' 
              : 'Your purchase history will appear here\nafter you complete a checkout.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey.shade500),
          ),
          if (isSearching) ...[
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _clearFilters,
              child: const Text('Clear Filters'),
            ),
          ],
        ],
      ),
    );
  }
}

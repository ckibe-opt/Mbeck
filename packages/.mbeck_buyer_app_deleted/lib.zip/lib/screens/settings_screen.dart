import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:mbeck_go/services/database_service.dart';
import 'package:mbeck_go/screens/onboarding_screen.dart';
import 'package:flutter/services.dart';
import 'privacy_policy_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _supabase = Supabase.instance.client;
  String? _deviceId;
  double _walletBalance = 0.0;
  bool _isLoading = true;
  bool _notificationsEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadUserInfo();
  }

  Future<void> _loadUserInfo() async {
    final prefs = await SharedPreferences.getInstance();
    final db = DatabaseService.instance.db;
    
    // Load local profile for wallet balance
    final user = _supabase.auth.currentUser;
    if (user != null) {
      final profile = await (db.select(db.userProfile)..where((t) => t.id.equals(user.id))).getSingleOrNull();
      if (profile != null) {
        _walletBalance = profile.walletBalance;
      }
    }

    setState(() {
      _deviceId = prefs.getString('buyer_device_id');
      _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
      _isLoading = false;
    });
  }

  Future<void> _logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout? your browsing data will be preserved locally.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true), 
            child: const Text('Logout', style: TextStyle(color: Colors.red))
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _supabase.auth.signOut();
      if (mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const OnboardingScreen()),
          (route) => false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _supabase.auth.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile & Settings'),
        elevation: 0,
      ),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // User Card
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      const CircleAvatar(
                        radius: 40,
                        backgroundColor: Colors.deepPurple,
                        child: Icon(Icons.person, size: 40, color: Colors.white),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        user?.email ?? 'Guest User',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Wallet Balance: Ksh ${_walletBalance.toStringAsFixed(2)}',
                        style: const TextStyle(color: Colors.green, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              
              const Text('Account Information', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
              const SizedBox(height: 8),
              ListTile(
                leading: const Icon(Icons.perm_device_information),
                title: const Text('Device ID'),
                subtitle: Text(_deviceId ?? 'Unknown'),
                trailing: const Icon(Icons.copy, size: 18),
                onTap: () async {
                  if (_deviceId != null) {
                    await Clipboard.setData(ClipboardData(text: _deviceId!));
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Device ID copied to clipboard')));
                    }
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.fingerprint),
                title: const Text('Internal UID'),
                subtitle: Text(user?.id ?? 'N/A'),
                onTap: () async {
                  if (user?.id != null) {
                    await Clipboard.setData(ClipboardData(text: user!.id));
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Internal UID copied to clipboard')));
                    }
                  }
                },
              ),

              const Divider(height: 32),
              
              const Text('Preferences', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey)),
               ListTile(
                leading: const Icon(Icons.notifications_none),
                title: const Text('Notifications'),
                trailing: Switch(
                  value: _notificationsEnabled, 
                  onChanged: (v) async {
                    setState(() => _notificationsEnabled = v);
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.setBool('notifications_enabled', v);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(v ? 'Notifications enabled' : 'Notifications disabled')));
                    }
                  },
                ),
              ),
              ListTile(
                leading: const Icon(Icons.security),
                title: const Text('Privacy Policy'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const PrivacyPolicyScreen()),
                  );
                },
              ),

              const SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: _logout,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.shade50,
                  foregroundColor: Colors.red,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: const Icon(Icons.logout),
                label: const Text('Logout from Mbeck'),
              ),
              const SizedBox(height: 8),
              const Center(
                child: Text(
                  'Version 1.0.0',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ),
            ],
          ),
    );
  }
}

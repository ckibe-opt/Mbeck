import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../providers/starred_provider.dart';
import '../providers/shop_session_provider.dart';

/// Buyer app settings screen.
class BuyerSettingsScreen extends StatelessWidget {
  const BuyerSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<ShopSessionProvider>();
    final starred = context.watch<StarredProvider>();
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Connection status
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 12, height: 12,
                        decoration: BoxDecoration(
                          color: session.isConnected ? Colors.green : Colors.grey,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        session.isConnected ? 'Connected' : 'Not Connected',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: session.isConnected ? Colors.green.shade700 : Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                  if (session.isConnected) ...[
                    const SizedBox(height: 12),
                    _infoTile('Shop', session.currentShopName ?? 'Unknown'),
                    _infoTile('Address', '${session.currentIp}:${session.currentPort}'),
                    _infoTile('Business Type', session.businessType ?? 'retail'),
                    _infoTile('Modules', session.enabledModules?.join(', ') ?? 'retail'),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () {
                          session.disconnect();
                        },
                        icon: const Icon(Icons.exit_to_app, color: Colors.red),
                        label: const Text('Disconnect', style: TextStyle(color: Colors.red)),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // App info
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: Icon(Icons.info_outline, color: theme.primaryColor),
                  title: const Text('Mbeck Buyer'),
                  subtitle: const Text('Version 1.0.0'),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: Icon(Icons.delete_outline, color: Colors.red.shade400),
                  title: const Text('Clear All Data'),
                  subtitle: const Text('Remove all saved receipts and preferences'),
                  onTap: () async {
                    final confirm = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Clear All Data?'),
                        content: const Text('This will remove all saved receipts, connection history, and preferences. This cannot be undone.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                          FilledButton(
                            onPressed: () => Navigator.pop(ctx, true),
                            style: FilledButton.styleFrom(backgroundColor: Colors.red),
                            child: const Text('Clear'),
                          ),
                        ],
                      ),
                    );
                    if (confirm == true) {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      session.disconnect();
                      starred.clearAll();
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('All data cleared')),
                        );
                      }
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoTile(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          SizedBox(width: 100, child: Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 13))),
          Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13))),
        ],
      ),
    );
  }
}

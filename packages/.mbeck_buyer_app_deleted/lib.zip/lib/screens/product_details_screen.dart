import 'package:flutter/material.dart';
import 'package:mbeck_shared/mbeck_shared.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import '../theme/shop_theme_extension.dart';

class ProductDetailsScreen extends StatefulWidget {
  final InventoryItem item;
  final String? shopName;
  final int? heroIndex; // For unique Hero tag matching

  const ProductDetailsScreen({
    super.key, 
    required this.item,
    this.shopName,
    this.heroIndex,
  });

  @override
  State<ProductDetailsScreen> createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  ProductVariation? _selectedVariation;

  @override
  void initState() {
    super.initState();
    // Select first variation by default if available
    if (widget.item.hasVariations) {
      _selectedVariation = widget.item.variations.first;
    }
  }

  /// Get the effective price based on selected variation
  double get effectivePrice {
    if (_selectedVariation != null) {
      return widget.item.sellingPrice + _selectedVariation!.priceModifier;
    }
    return widget.item.sellingPrice;
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final isOutOfStock = item.stock <= 0;
    
    // Security/Privacy Stock Logic
    String stockText;
    Color stockColor;
    
    if (item.stock <= 0) {
      stockText = 'Out of Stock';
      stockColor = Colors.red;
    } else if (item.stock < 5) {
      stockText = 'Only ${item.stock} left!';
      stockColor = Colors.orange;
    } else if (item.stock > 10) {
      stockText = '10+ in stock';
      stockColor = Colors.green;
    } else {
      stockText = '${item.stock} in stock';
      stockColor = Colors.green;
    }

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar with Image
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Hero(
                tag: widget.heroIndex != null 
                    ? 'product_image_${item.id}_${widget.heroIndex}' 
                    : 'product_image_${item.id}',
                child: item.imagePath != null && item.imagePath!.isNotEmpty
                  ? Image.network(
                      item.imagePath!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: Colors.grey.shade200,
                        child: const Icon(Icons.broken_image, size: 64, color: Colors.grey),
                      ),
                    )
                  : Container(
                      color: Colors.grey.shade200,
                      child: const Icon(Icons.shopping_bag, size: 64, color: Colors.grey),
                    ),
              ),
            ),
          ),
          
          // Content
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Builder(
                builder: (ctx) {
                  final ext = Theme.of(ctx).extension<ShopThemeExtension>() ?? const ShopThemeExtension();
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Badges
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: stockColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(ext.chipBorderRadius),
                              border: Border.all(color: stockColor),
                            ),
                            child: Text(
                              stockText,
                              style: TextStyle(
                                color: stockColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ),
                          if (item.category != null) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(ext.chipBorderRadius),
                              ),
                              child: Text(
                                item.category!,
                                style: TextStyle(
                                  color: Colors.grey.shade700,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                          if (item.hasVariations) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.blue.shade50,
                                borderRadius: BorderRadius.circular(ext.chipBorderRadius),
                              ),
                              child: Text(
                                '${item.variations.length} sizes',
                                style: TextStyle(
                                  color: Colors.blue.shade700,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                  const SizedBox(height: 16),
                  
                  // Title
                  Text(
                    item.name,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      height: 1.2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  
                  // Price
                  Text(
                    CurrencyFormatter.formatWithCurrency(effectivePrice),
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                  
                  // Variation Selector
                  if (item.hasVariations) ...[
                    const SizedBox(height: 20),
                    const Text(
                      'Select Size',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: item.variations.map((variation) {
                        final isSelected = _selectedVariation?.id == variation.id;
                        return ChoiceChip(
                          label: Text(variation.name),
                          selected: isSelected,
                          onSelected: (selected) {
                            setState(() => _selectedVariation = variation);
                          },
                          labelStyle: TextStyle(
                            color: isSelected ? Colors.white : Colors.black87,
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          ),
                          selectedColor: Theme.of(context).primaryColor,
                          avatar: variation.priceModifier != 0
                              ? Text(
                                  variation.priceModifier > 0 ? '+' : '',
                                  style: TextStyle(
                                    color: isSelected ? Colors.white : Colors.grey,
                                    fontSize: 12,
                                  ),
                                )
                              : null,
                        );
                      }).toList(),
                    ),
                    if (_selectedVariation != null && _selectedVariation!.priceModifier != 0)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                          _selectedVariation!.priceModifier > 0
                              ? '+${CurrencyFormatter.formatWithCurrency(_selectedVariation!.priceModifier)}'
                              : 'Save ${CurrencyFormatter.formatWithCurrency(-_selectedVariation!.priceModifier)}',
                          style: TextStyle(
                            color: _selectedVariation!.priceModifier > 0 
                                ? Colors.orange 
                                : Colors.green,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                  ],
                  
                  const Divider(height: 48),
                  
                  // Specifications
                  const Text(
                    'Details',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  if (item.specification != null && item.specification!.isNotEmpty)
                    Text(
                      item.specification!,
                      style: TextStyle(
                        fontSize: 16, 
                        color: Colors.grey.shade800,
                        height: 1.5,
                      ),
                    )
                  else
                    Text(
                      'No additional details available for this product.',
                      style: TextStyle(color: Colors.grey.shade500, fontStyle: FontStyle.italic),
                    ),
                    
                  if (item.barcode != null && item.barcode!.isNotEmpty) ...[
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        const Icon(Icons.qr_code, color: Colors.grey, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          'SKU: ${item.barcode}',
                          style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
                        ),
                      ],
                    ),
                  ],
                    
                  const SizedBox(height: 100), // Space for bottom bar
                ],
              );
                },
              ),
            ),
          ),
        ],
      ),
      
      // Bottom Bar
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: SafeArea(
          child: Row(
            children: [
               Expanded(
                 child: FilledButton.icon(
                   onPressed: isOutOfStock
                       ? null
                       : () {
                           context.read<CartProvider>().addItem(
                             item,
                             variation: _selectedVariation,
                           );
                           final displayName = _selectedVariation != null
                               ? '${item.name} (${_selectedVariation!.name})'
                               : item.name;
                           ScaffoldMessenger.of(context).showSnackBar(
                             SnackBar(
                               content: Text('Added $displayName to cart'),
                               backgroundColor: Colors.green,
                               behavior: SnackBarBehavior.floating,
                             ),
                           );
                         },
                   icon: const Icon(Icons.add_shopping_cart),
                   label: Text(isOutOfStock ? 'Out of Stock' : 'Add to Cart'),
                   style: FilledButton.styleFrom(
                     backgroundColor: isOutOfStock ? Colors.grey : Colors.green,
                     minimumSize: const Size(double.infinity, 56),
                     textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                   ),
                 ),
               ),
            ],
          ),
        ),
      ),
    );
  }
}

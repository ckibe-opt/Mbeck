import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';
import '../models/permissions.dart';
import 'auth_service.dart';

class UnmetDemandItem {
  final String query;
  final int count;
  final DateTime lastSeen;

  UnmetDemandItem({
    required this.query,
    required this.count,
    required this.lastSeen,
  });

  factory UnmetDemandItem.fromJson(Map<String, dynamic> json) {
    return UnmetDemandItem(
      query: json['query_text'] ?? 'Unknown',
      count: json['demand_count'] ?? 0,
      lastSeen: DateTime.tryParse(json['last_seen_at'] ?? '') ?? DateTime.now(),
    );
  }
}

class AnalyticsService {
  static final SupabaseClient _supabase = Supabase.instance.client;

  /// Fetch top missed opportunities (unmet demand)
  static Future<List<UnmetDemandItem>> getUnmetDemand({int limit = 5}) async {
    // RBAC Check
    final member = await AuthService.getCurrentMember();
    if (member != null && !member.hasPermission(Permissions.viewReports)) {
      debugPrint('⛔ Analytics Access Denied for ${member.userName}');
      return [];
    }

    try {
      // Return empty if offline or anon
      if (_supabase.auth.currentUser == null) return [];

      final List<dynamic> response = await _supabase
          .from('analytics_demand_unmet')
          .select()
          .limit(limit);

      return response.map((e) => UnmetDemandItem.fromJson(e)).toList();
    } catch (e) {
      debugPrint('⚠️ Analytics Fetch Failed: $e');
      return [];
    }
  }
}

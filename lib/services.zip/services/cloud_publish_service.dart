import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../db/db_provider.dart';
import 'device_service.dart';
import 'onboarding_service.dart';
import 'cloud_storage_service.dart';

class CloudPublishService {
  static const String _shopsTable = 'shops';
  static const String _inventoryTable = 'inventory';
  static const String _rateLimitKey = 'cloud_auth_rate_limit_until';
  static const int _backoffMinutes = 15;

  /// Ensure we have a Supabase session, using anonymous auth with backoff.
  /// Returns the authenticated user or null if unavailable.
  static Future<User?> _ensureAuth() async {
    final supabase = Supabase.instance.client;
    final existing = supabase.auth.currentUser;
    if (existing != null) return existing;

    // Check rate-limit backoff
    final prefs = await SharedPreferences.getInstance();
    final backoffUntil = prefs.getInt(_rateLimitKey) ?? 0;
    if (DateTime.now().millisecondsSinceEpoch < backoffUntil) {
      final remaining = ((backoffUntil - DateTime.now().millisecondsSinceEpoch) / 60000).ceil();
      debugPrint('⏳ Cloud auth on cooldown (${remaining}m remaining). Skipping.');
      return null;
    }

    debugPrint('� No user found, attempting anonymous auth...');
    try {
      final response = await supabase.auth.signInAnonymously();
      debugPrint('✅ Anonymous auth successful');
      return response.user;
    } on AuthException catch (e) {
      if (e.statusCode == '429' || e.message.toLowerCase().contains('rate limit')) {
        final until = DateTime.now().millisecondsSinceEpoch + (_backoffMinutes * 60 * 1000);
        await prefs.setInt(_rateLimitKey, until);
        debugPrint('⚠️ Rate limited. Backing off for ${_backoffMinutes}m.');
      } else {
        debugPrint('⚠️ Auth error: ${e.message}');
      }
      return null;
    } catch (e, stack) {
      debugPrint('❌ Cloud sync failed: $e');
      debugPrint('Stack trace: $stack');
      return null;
    }
  }

  /// Publishes the current shop details and inventory to the public cloud.
  /// Silently skips if cloud is unavailable (offline-first).
  static Future<void> publishShopAndInventory() async {
    final user = await _ensureAuth();
    if (user == null) {
      debugPrint('☁️ Cloud publish skipped — no auth session.');
      return;
    }
    
    final supabase = Supabase.instance.client;
    try {

    // 1. Get Local Data
    final cloudShopId = await DeviceService.getShopId() ?? user.id;

    // 2. Upsert Shop Details
    final localShops = await DbProvider.query('shops');
    Map<String, dynamic> themeConfig = {};
    String? businessName;
    String? passwordHash;
    bool isPublishedOnline = false;
    String currency = 'KES';
    
    if (localShops.isNotEmpty) {
      final localShop = localShops.first;
      businessName = (localShop['business_name']?.toString() ?? localShop['name']?.toString());
      passwordHash = localShop['password_hash'] ?? localShop['shop_password'];
      isPublishedOnline = localShop['is_published_online'] == 1;
      currency = localShop['currency']?.toString() ?? 'KES';
      
      if (localShop['theme_config'] != null) {
        if (localShop['theme_config'] is String) {
          try {
            themeConfig = json.decode(localShop['theme_config']);
          } catch (e) {
            debugPrint('⚠️ Error decoding theme_config: $e');
          }
        } else if (localShop['theme_config'] is Map) {
          themeConfig = localShop['theme_config'];
        }
      }
    }

    // 🛡️ HARDENING: Prioritize local DB name (source of truth) over potentially stale metadata
    final shopName = businessName ?? user.userMetadata?['business_name'] ?? 'Mbeck Shop';

    debugPrint('☁️ Publishing shop: $shopName ($cloudShopId)... visibility: $isPublishedOnline');

    // Update Supabase user metadata if the name is different to keep ecosystem consistent
    if (user.userMetadata?['business_name'] != shopName) {
      try {
        await supabase.auth.updateUser(UserAttributes(data: {'business_name': shopName}));
      } catch (e) {
        debugPrint('⚠️ Failed to update user metadata: $e');
      }
    }

    final prefs = await SharedPreferences.getInstance();
    final isRetailPublished = prefs.getBool('publish_retail') ?? false;
    final isServicesPublished = prefs.getBool('publish_services') ?? false;
    final isMenuPublished = prefs.getBool('publish_menu') ?? false;
    final isLodgingPublished = prefs.getBool('publish_lodging') ?? false;
    final isEntertainmentPublished = prefs.getBool('publish_entertainment') ?? false;

    // Get active modules to sync discovery state
    final activeModules = await OnboardingService.getSelectedModules();

    // Upsert shop - Hardened with safe fallbacks for required non-null columns
    await supabase.from(_shopsTable).upsert({
      'id': cloudShopId,
      'name': shopName,
      // The cloud 'shops' table has a NOT NULL constraint on password_hash.
      // If we don't have it locally, we must provide a non-null fallback to prevent sync failure.
      'password_hash': 'synced_placeholder', 
      'owner_device_id': await DeviceService.getDeviceId() ?? cloudShopId,
      'owner_id': user.id, // Ensure owner_id is set for RLS compliance
      'updated_at': DateTime.now().toIso8601String(),
      'branding': themeConfig,
      'enabled_modules': activeModules, // Ensure Buyer app can discover all modules
      'currency': currency, // Sync currency to cloud
      'is_retail_published': isRetailPublished,
      'is_services_published': isServicesPublished,
      'is_restaurant_published': isMenuPublished,
      'is_lodging_published': isLodgingPublished,
      'is_entertainment_published': isEntertainmentPublished,
      'is_published_online': isPublishedOnline,
      'verification_status': 'VERIFIED',
    });

    // 3. Upsert Unified Marketplace Items
    final List<Map<String, dynamic>> itemsToUpsert = [];

    Future<void> loadModuleData(String table, String moduleName) async {
      try {
        final db = await DbProvider.db;
        List<Map<String, dynamic>> data;
        
        if (moduleName == 'lodging') {
          data = await db.rawQuery('''
            SELECT r.*, rt.is_published as type_published
            FROM lodging_rooms r
            JOIN lodging_room_types rt ON r.room_type_id = rt.id
            WHERE r.is_active = 1
          ''');
        } else if (moduleName == 'entertainment') {
          data = await db.rawQuery('''
            SELECT a.*, at_.is_published as type_published
            FROM entertainment_assets a
            JOIN entertainment_asset_types at_ ON a.asset_type_id = at_.id
            WHERE a.is_active = 1
          ''');
        } else {
          data = await DbProvider.query(table);
        }

        for (final row in data) {
          final cloudId = row['cloud_id']?.toString();
          if (cloudId == null || cloudId.isEmpty) continue;

          // Honor type-level or item-level publishing
          final int itemPublished = row['type_published'] ?? row['is_published'] ?? 1;
          if (itemPublished == 0) continue;

          // Handle image upload
          String? imageUrl = (row['image_path'] ?? row['imagePath'])?.toString();
          if (imageUrl != null && imageUrl.isNotEmpty && !imageUrl.startsWith('http')) {
            try {
              final appDir = await getApplicationDocumentsDirectory();
              final fullPath = p.join(appDir.path, p.basename(imageUrl));
              final cloudUrl = await CloudStorageService.uploadImage(fullPath, folder: 'marketplace');
              if (cloudUrl != null && cloudUrl.startsWith('http')) {
                imageUrl = cloudUrl;
              }
            } catch (e) {
              debugPrint('⚠️ Image upload failed for item: $e');
            }
          }

          // Map module-specific metadata
          final Map<String, dynamic> metadata = {
            'barcode': row['barcode'],
            'preparation_time_mins': row['prep_time_minutes'],
            'duration_minutes': row['duration_minutes'],
            'capacity': row['capacity'],
            'amenities': row['amenities'],
            'rate_per_week': row['rate_per_week'],
            'rate_per_month': row['rate_per_month'],
            'rate_per_hour': row['rate_per_hour'],
            'flat_rate': row['flat_rate'],
            'asset_type': row['asset_type'], // e.g. 'hourly', 'flat'
            'variations_json': row['variationsJson'] ?? row['variations_json'], // Gap 2
          };

          // Fetch restaurant modifiers (Gap 4)
          if (moduleName == 'restaurant') {
            try {
              final db = await DbProvider.db;
              final itemId = row['id'];
              final groups = await db.query('restaurant_modifier_groups', where: 'menu_item_id = ?', whereArgs: [itemId]);
              final List<Map<String, dynamic>> modifierGroupsWithItems = [];
              for (final group in groups) {
                final modifiers = await db.query('restaurant_modifiers', where: 'group_id = ?', whereArgs: [group['id']]);
                modifierGroupsWithItems.add({
                  'name': group['name'],
                  'min': group['min_selections'],
                  'max': group['max_selections'],
                  'options': modifiers.map((m) => {
                    'name': m['name'],
                    'price': m['price_adjustment'],
                    'available': m['available'],
                  }).toList(),
                });
              }
              metadata['modifier_groups_json'] = jsonEncode(modifierGroupsWithItems);
            } catch (e) {
              debugPrint('⚠️ Failed to load restaurant modifiers: $e');
            }
          }

          metadata.removeWhere((k, v) => v == null);

          itemsToUpsert.add({
            'id': cloudId,
            'shop_id': cloudShopId,
            'module_source': moduleName,
            'name': row['name']?.toString() ?? 'Unnamed Item',
            'description': (row['description'] ?? row['specification'])?.toString(),
            'price': (row['price'] ?? row['sellingPrice'] ?? row['rate_per_night'] ?? row['rate'] ?? 0),
            'original_price': row['originalPrice'],
            'image_url': imageUrl,
            'category': row['category']?.toString(),
            'is_published': isPublishedOnline == true && itemPublished == 1,
            'stock': row['stock'],
            'metadata': metadata,
          });
        }
      } catch (e) {
        debugPrint('⚠️ Skipped syncing $table: $e');
      }
    }

    if (activeModules.contains('retail')) await loadModuleData('inventory', 'retail');
    if (activeModules.contains('restaurant')) await loadModuleData('restaurant_menu', 'restaurant');
    if (activeModules.contains('services')) await loadModuleData('services_catalog', 'services');
    if (activeModules.contains('lodging')) await loadModuleData('lodging_rooms', 'lodging');
    if (activeModules.contains('entertainment')) await loadModuleData('entertainment_assets', 'entertainment');

    if (itemsToUpsert.isNotEmpty) {
      const batchSize = 100;
      for (var i = 0; i < itemsToUpsert.length; i += batchSize) {
        final end = (i + batchSize < itemsToUpsert.length) ? i + batchSize : itemsToUpsert.length;
        final batch = itemsToUpsert.sublist(i, end);
        await supabase.from('marketplace_items').upsert(batch);
      }
      debugPrint('✅ Published ${itemsToUpsert.length} items to unified marketplace cloud.');
    } else {
      debugPrint('☁️ No items to publish. Skipping marketplace items.');
    }

    try {
      await supabase.rpc('log_analytics_event', params: {
        'p_event_name': 'SHOP_PUBLISHED',
        'p_platform': 'seller',
        'p_shop_id': cloudShopId,
        'p_details': {
          'items_count': itemsToUpsert.length,
          'shop_name': shopName,
        }
      });
    } catch (e) {
      debugPrint('⚠️ Failed to log analytics: $e');
    }
    } catch (e, stack) {
      debugPrint('❌ Cloud publish error: $e');
      debugPrint(stack.toString());
      rethrow;
    }
  }
}
